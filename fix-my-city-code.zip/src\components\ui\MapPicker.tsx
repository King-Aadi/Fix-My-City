import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, useMapEvents, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix Leaflet icon issue
delete (L.Icon.Default.prototype as unknown as { _getIconUrl?: unknown })._getIconUrl;
L.Icon.Default.mergeOptions({
    iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
    iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface MapPickerProps {
    initialLat?: number;
    initialLng?: number;
    onLocationSelect: (lat: number, lng: number) => void;
}

const LocationMarker: React.FC<{ onSelect: (lat: number, lng: number) => void, position: { lat: number; lng: number } | null }> = ({ onSelect, position }) => {
    useMapEvents({
        click(e) {
            onSelect(e.latlng.lat, e.latlng.lng);
        },
    });

    return position ? <Marker position={position} /> : null;
};

const Recenter: React.FC<{ lat: number; lng: number }> = ({ lat, lng }) => {
    const map = useMap();
    useEffect(() => {
        map.setView([lat, lng]);
    }, [lat, lng, map]);
    return null;
};

const MapPicker: React.FC<MapPickerProps> = ({ initialLat = 12.9716, initialLng = 77.5946, onLocationSelect }) => {
    const [position, setPosition] = useState<{ lat: number; lng: number } | null>(null);

    // State is initialized from props. Parent should use key to reset if needed.

    const handleSelect = (lat: number, lng: number) => {
        setPosition({ lat, lng });
        // Reverse Geocoding would happen here in a real app to get address
        onLocationSelect(lat, lng);
    };

    return (
        <div className="h-full w-full relative z-0">
            <MapContainer
                center={[initialLat, initialLng]}
                zoom={13}
                className="h-full w-full rounded-xl"
                style={{ height: '100%', width: '100%' }}
            >
                <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                />
                <LocationMarker onSelect={handleSelect} position={position} />
                {position && <Recenter lat={position.lat} lng={position.lng} />}
            </MapContainer>
            <div className="absolute bottom-2 left-2 bg-white px-2 py-1 rounded shadow text-xs z-[1000] opacity-80">
                Tap map to pin location
            </div>
        </div>
    );
};

export default MapPicker;
