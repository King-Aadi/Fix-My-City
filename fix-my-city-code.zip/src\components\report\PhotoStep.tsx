import React, { useState, useRef } from 'react';
import { Camera, X, Image as ImageIcon } from 'lucide-react';
import Button from '../../components/ui/Button';
import { analyzeImage } from '../../services/ai';
import FaceCapture from '../../components/ui/FaceCapture';

interface PhotoStepProps {
    onNext: (data: { image: File; description: string }) => void;
    onBack: () => void;
}

const PhotoStep: React.FC<PhotoStepProps> = ({ onNext, onBack }) => {
    const [image, setImage] = useState<File | null>(null);
    const [preview, setPreview] = useState<string | null>(null);
    const [analyzing, setAnalyzing] = useState(false);
    const [description, setDescription] = useState('');
    const [showCamera, setShowCamera] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            processFile(e.target.files[0]);
        }
    };

    const handleCameraCapture = (file: File, dataUrl: string) => {
        setImage(file);
        setPreview(dataUrl);
        setShowCamera(false);
        performAnalysis(file);
    };

    const processFile = (file: File) => {
        setImage(file);
        setPreview(URL.createObjectURL(file));
        performAnalysis(file);
    };

    const performAnalysis = async (file: File) => {
        setAnalyzing(true);
        try {
            // Determine AI Type
            const result = await analyzeImage(file); // Assume this is imported
            setDescription(`Identified: ${result.type}. Confidence: ${(result.confidence * 100).toFixed(0)}%.\nTags: ${result.tags.join(', ')}.`);
        } catch (err) {
            console.error(err);
            setDescription("Could not analyze image. Please describe the issue.");
        } finally {
            setAnalyzing(false);
        }
    };

    const handleNext = () => {
        if (image && description) {
            onNext({ image, description });
        }
    };

    if (showCamera) {
        return (
            <div className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center p-4">
                <div className="w-full max-w-md bg-white rounded-2xl overflow-hidden shadow-2xl">
                    <div className="p-4 flex justify-between items-center border-b">
                        <h3 className="font-bold text-lg">Take Photo</h3>
                        <button onClick={() => setShowCamera(false)} className="p-2 hover:bg-gray-100 rounded-full">
                            <X className="h-6 w-6" />
                        </button>
                    </div>
                    <div className="p-4">
                        <FaceCapture
                            onCapture={handleCameraCapture}
                            label="Capture Issue"
                            enableFaceDetection={false}
                            className="w-full"
                        />
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="space-y-6 animate-fade-in relative">
            <div className="text-center space-y-2">
                <h2 className="text-2xl font-bold text-gray-900">Step 2: Evidence</h2>
                <p className="text-gray-500">Take a clear photo for AI analysis.</p>
            </div>

            {!preview ? (
                <div className="space-y-4">
                    {/* Main Camera Option */}
                    <div
                        className="bg-blue-50 h-56 rounded-2xl flex flex-col items-center justify-center border-2 border-dashed border-blue-200 cursor-pointer hover:bg-blue-100 hover:border-blue-400 hover:shadow-lg transition-all duration-300 group"
                        onClick={() => setShowCamera(true)}
                    >
                        <div className="bg-white p-4 rounded-full shadow-sm mb-4 group-hover:scale-110 transition-transform">
                            <Camera className="h-10 w-10 text-blue-600" />
                        </div>
                        <p className="text-blue-900 font-semibold text-lg">Open Camera</p>
                        <p className="text-sm text-blue-500 mt-1">Take a photo directly</p>
                    </div>

                    {/* Gallery Option */}
                    <div
                        className="bg-gray-50 h-20 rounded-xl flex items-center justify-center border border-gray-200 cursor-pointer hover:bg-gray-100 transition-all gap-3"
                        onClick={() => fileInputRef.current?.click()}
                    >
                        <ImageIcon className="h-5 w-5 text-gray-500" />
                        <span className="text-gray-700 font-medium">Upload from Gallery</span>
                    </div>

                    <input
                        type="file"
                        ref={fileInputRef}
                        className="hidden"
                        accept="image/*"
                        onChange={handleFileChange}
                    />
                </div>
            ) : (
                <div className="relative h-72 rounded-2xl overflow-hidden bg-black shadow-lg">
                    <img src={preview} alt="Issue preview" className="w-full h-full object-contain" />
                    <button
                        onClick={() => {
                            setImage(null);
                            setPreview(null);
                            setDescription('');
                        }}
                        className="absolute top-4 right-4 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full backdrop-blur-sm transition-all"
                    >
                        <X className="h-5 w-5" />
                    </button>
                </div>
            )}

            {analyzing && (
                <div className="bg-blue-50 border border-blue-100 rounded-xl p-6 text-center animate-pulse">
                    <div className="h-2 bg-blue-200 rounded w-3/4 mx-auto mb-3"></div>
                    <div className="h-2 bg-blue-200 rounded w-1/2 mx-auto"></div>
                    <p className="text-blue-600 font-medium text-sm mt-4">AI is analyzing the scene...</p>
                </div>
            )}

            {!analyzing && description && (
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-2xl border border-blue-100 shadow-sm relative overflow-hidden">
                    <div className="absolute top-0 right-0 -mt-2 -mr-2 w-16 h-16 bg-blue-200 rounded-full blur-2xl opacity-50"></div>
                    <label className="block text-xs font-bold text-blue-700 uppercase tracking-wide mb-2">
                        AI Generated Report
                    </label>
                    <textarea
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        className="w-full text-base text-gray-900 bg-transparent border-none focus:ring-0 p-0 resize-none h-20 font-medium leading-relaxed"
                    />
                </div>
            )}

            <div className="flex gap-4">
                <Button onClick={onBack} variant="outline" className="flex-1">
                    Back
                </Button>
                <Button
                    onClick={handleNext}
                    disabled={!image || !description || analyzing}
                    className="flex-1"
                >
                    Next Step
                </Button>
            </div>
        </div>
    );
};

export default PhotoStep;
