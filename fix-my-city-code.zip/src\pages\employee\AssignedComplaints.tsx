import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Filter, AlertTriangle, Clock, MapPin, ChevronRight, Briefcase } from 'lucide-react';
import Card from '../../components/ui/Card';
import Input from '../../components/ui/Input';
import Button from '../../components/ui/Button';
import { db } from '../../services/storage';
import { useComplaints } from '../../hooks/useComplaints';

const AssignedComplaints: React.FC = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const { complaints: allComplaints } = useComplaints(); // Reactive data

    // Memoize filtered complaints to avoid unnecessary calculations
    const filteredComplaints = React.useMemo(() => {
        const user = db.getCurrentUser();
        let filtered = allComplaints.filter(c => c.status !== 'Resolved');

        if (user && user.role === 'employee' && user.zone) {
            filtered = filtered.filter(c => c.zone === user.zone);
        }

        return filtered.filter(c =>
            c.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
            c.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
            c.type.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [allComplaints, searchTerm]);

    const [now] = useState(() => Date.now());

    const getDaysRemaining = (dateStr: string) => {
        const daysPassed = Math.floor((now - new Date(dateStr).getTime()) / (1000 * 60 * 60 * 24));
        return Math.max(0, 14 - daysPassed); // Assuming 14 day SLA
    };

    return (
        <div className="p-4 max-w-7xl mx-auto space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Assigned Tasks</h1>
                    <p className="text-gray-500 text-sm">Manage your active workload</p>
                </div>
                <div className="bg-green-100 p-2 rounded-lg">
                    <Briefcase className="h-6 w-6 text-green-700" />
                </div>
            </div>

            <div className="flex gap-4">
                <div className="flex-grow">
                    <Input
                        placeholder="Search by ID or Location..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        icon={<Search className="h-5 w-5" />}
                        fullWidth
                        className="mb-0"
                    />
                </div>
                <Button variant="outline" className="px-4">
                    <Filter className="h-5 w-5 text-gray-500" />
                </Button>
            </div>

            <div className="space-y-4">
                {filteredComplaints.length > 0 ? (
                    filteredComplaints.map(complaint => {
                        const daysRemaining = getDaysRemaining(complaint.date);
                        return (
                            <Link
                                key={complaint.id}
                                to={`/employee/complaint/${complaint.id}/manage`}
                                className="block group"
                            >
                                <Card className="hover:border-green-400 border-l-4 border-l-transparent hover:border-l-green-500 transition-all" padding="md">
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <div className="flex items-center space-x-2 mb-2">
                                                <span className="font-bold text-gray-900 text-lg group-hover:text-green-700 transition-colors">{complaint.type}</span>
                                                {complaint.priority === 'High' && (
                                                    <span className="flex items-center text-[10px] text-red-700 bg-red-100 px-2 py-0.5 rounded-full font-bold uppercase tracking-wide border border-red-200">
                                                        <AlertTriangle className="h-3 w-3 mr-1" /> High Priority
                                                    </span>
                                                )}
                                            </div>
                                            <div className="flex items-center text-sm text-gray-500 mb-1">
                                                <MapPin className="h-4 w-4 mr-1 text-gray-400" />
                                                {complaint.location}
                                                {complaint.zone && <span className="ml-2 text-xs bg-gray-100 px-1 rounded text-gray-600">({complaint.zone})</span>}
                                            </div>
                                            <div className="flex items-center text-xs text-gray-400 mt-2 font-mono bg-gray-50 inline-block px-1 rounded">
                                                ID: {complaint.id}
                                            </div>
                                        </div>
                                        <div className="text-right flex flex-col items-end">
                                            <span className={`inline-block px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide mb-2 ${complaint.status === 'In Progress' ? 'bg-yellow-100 text-yellow-800 border border-yellow-200' : 'bg-blue-100 text-blue-800 border border-blue-200'
                                                }`}>
                                                {complaint.status}
                                            </span>
                                            <div className={`flex items-center text-xs font-medium ${daysRemaining < 3 ? 'text-red-500' : 'text-green-600'}`}>
                                                <Clock className="h-3 w-3 mr-1" />
                                                <span>{daysRemaining} days left</span>
                                            </div>

                                            <div className="mt-4 p-1 rounded-full bg-gray-50 group-hover:bg-green-50 transition-colors">
                                                <ChevronRight className="h-5 w-5 text-gray-300 group-hover:text-green-600" />
                                            </div>
                                        </div>
                                    </div>
                                </Card>
                            </Link>
                        )
                    })
                ) : (
                    <div className="text-center py-10 text-gray-500">
                        No assigned complaints found in your zone.
                    </div>
                )}
            </div>
        </div>
    );
};

export default AssignedComplaints;
