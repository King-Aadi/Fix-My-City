import { useState, useEffect, useCallback } from 'react';
import { db } from '../services/storage';
import type { Complaint } from '../services/storage';

export const useComplaints = () => {
    const [complaints, setComplaints] = useState<Complaint[]>(() => db.getComplaints());
    const [loading, setLoading] = useState(false);

    const refresh = useCallback(() => {
        const data = db.getComplaints();
        setComplaints(data);
        setLoading(false);
    }, []);

    useEffect(() => {
        const handleStorageUpdate = () => {
            refresh();
        };

        window.addEventListener('fmc-storage-update', handleStorageUpdate);

        return () => {
            window.removeEventListener('fmc-storage-update', handleStorageUpdate);
        };
    }, [refresh]);

    return { complaints, loading, refresh };
};
