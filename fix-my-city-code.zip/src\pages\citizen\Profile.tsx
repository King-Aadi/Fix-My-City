import React, { useState } from 'react';
import { User, Mail, Phone, LogOut, Award, Shield, Edit2, Save, X } from 'lucide-react';
import Card from '../../components/ui/Card';
import Input from '../../components/ui/Input';
import Button from '../../components/ui/Button';
import { useAuth } from '../../context/AuthContext';
import { db } from '../../services/storage';

const CitizenProfile: React.FC = () => {
    const { user, logout, updateProfile } = useAuth();
    const [isEditing, setIsEditing] = useState(false);
    const [formData, setFormData] = useState(() => {
        if (!user) return { name: '', phone: '', email: '' };
        return {
            name: user.name,
            phone: user.phone || '',
            email: user.email
        };
    });

    // useEffect removed - state initialized from user prop directly


    const handleSave = () => {
        if (!user) return;
        updateProfile({
            name: formData.name,
            phone: formData.phone
        });
        setIsEditing(false);
    };

    if (!user) return <div className="p-8 text-center">Please login to view profile.</div>;

    // Calc Stats
    const complaints = db.getComplaints().filter(c => c.userId === user.id);
    const resolved = complaints.filter(c => c.status === 'Resolved').length;

    return (
        <div className="min-h-screen bg-gray-50 pb-20">
            {/* Header / Banner */}
            <div className="bg-gradient-primary h-48 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-white opacity-10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl"></div>
                <div className="absolute bottom-0 left-0 w-48 h-48 bg-black opacity-10 rounded-full translate-y-1/2 -translate-x-1/2 blur-2xl"></div>
            </div>

            <div className="max-w-3xl mx-auto px-4 -mt-20">
                <div className="flex flex-col items-center">
                    <div className="h-32 w-32 bg-white rounded-full p-2 shadow-xl border-4 border-white/50 backdrop-blur-sm relative group">
                        <div className="h-full w-full bg-blue-100 rounded-full flex items-center justify-center text-primary overflow-hidden">
                            {/* Placeholder Avatar */}
                            <span className="text-4xl font-bold">{user.name.charAt(0).toUpperCase()}</span>
                        </div>
                    </div>
                    <div className="text-center mt-4 mb-8">
                        <h1 className="text-2xl font-bold text-gray-900">{user.name}</h1>
                        <p className="text-gray-500">Citizen • {user.email}</p>
                    </div>
                </div>

                <div className="space-y-6">
                    {/* Impact Stats */}
                    <Card className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white border-none shadow-lg">
                        <div className="flex justify-around items-center py-2">
                            <div className="text-center">
                                <div className="flex items-center justify-center h-10 w-10 bg-white/20 rounded-full mx-auto mb-2 backdrop-blur-lg">
                                    <Award className="h-5 w-5" />
                                </div>
                                <div className="text-2xl font-bold">{complaints.length}</div>
                                <div className="text-xs font-medium opacity-80 uppercase tracking-wider">Reports</div>
                            </div>
                            <div className="w-px h-12 bg-white/20"></div>
                            <div className="text-center">
                                <div className="flex items-center justify-center h-10 w-10 bg-white/20 rounded-full mx-auto mb-2 backdrop-blur-lg">
                                    <Shield className="h-5 w-5" />
                                </div>
                                <div className="text-2xl font-bold">{resolved}</div>
                                <div className="text-xs font-medium opacity-80 uppercase tracking-wider">Resolved</div>
                            </div>
                        </div>
                    </Card>

                    <Card>
                        <div className="flex justify-between items-center mb-4 border-b border-gray-100 pb-2">
                            <h3 className="text-gray-900 font-bold">Personal Information</h3>
                            {!isEditing ? (
                                <button onClick={() => setIsEditing(true)} className="text-blue-600 hover:bg-blue-50 p-2 rounded-full transition-colors">
                                    <Edit2 className="h-4 w-4" />
                                </button>
                            ) : (
                                <div className="flex gap-2">
                                    <button onClick={() => setIsEditing(false)} className="text-gray-400 hover:bg-gray-100 p-2 rounded-full transition-colors">
                                        <X className="h-4 w-4" />
                                    </button>
                                    <button onClick={handleSave} className="text-green-600 hover:bg-green-50 p-2 rounded-full transition-colors">
                                        <Save className="h-4 w-4" />
                                    </button>
                                </div>
                            )}
                        </div>

                        <div className="space-y-4">
                            {!isEditing ? (
                                <>
                                    <div className="flex items-center p-3 hover:bg-gray-50 rounded-xl transition-colors">
                                        <div className="bg-blue-50 p-2 rounded-full mr-4">
                                            <User className="h-5 w-5 text-blue-600" />
                                        </div>
                                        <div className="flex-1">
                                            <p className="text-xs text-gray-500 font-medium uppercase">Full Name</p>
                                            <p className="text-gray-900 font-medium">{user.name}</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center p-3 hover:bg-gray-50 rounded-xl transition-colors">
                                        <div className="bg-blue-50 p-2 rounded-full mr-4">
                                            <Mail className="h-5 w-5 text-blue-600" />
                                        </div>
                                        <div className="flex-1">
                                            <p className="text-xs text-gray-500 font-medium uppercase">Email</p>
                                            <p className="text-gray-900 font-medium">{user.email}</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center p-3 hover:bg-gray-50 rounded-xl transition-colors">
                                        <div className="bg-blue-50 p-2 rounded-full mr-4">
                                            <Phone className="h-5 w-5 text-blue-600" />
                                        </div>
                                        <div className="flex-1">
                                            <p className="text-xs text-gray-500 font-medium uppercase">Phone</p>
                                            <p className="text-gray-900 font-medium">{user.phone && user.phone !== user.email ? user.phone : 'Not Set'}</p>
                                        </div>
                                    </div>
                                </>
                            ) : (
                                <div className="space-y-4 animate-fade-in">
                                    <Input
                                        label="Full Name"
                                        value={formData.name}
                                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                        icon={<User className="h-5 w-5" />}
                                    />
                                    <Input
                                        label="Phone Number"
                                        value={formData.phone}
                                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                                        icon={<Phone className="h-5 w-5" />}
                                    />
                                    <div className="opacity-50 pointer-events-none">
                                        <Input
                                            label="Email (Cannot be changed)"
                                            value={formData.email}
                                            readOnly
                                            icon={<Mail className="h-5 w-5" />}
                                        />
                                    </div>
                                    <Button onClick={handleSave} fullWidth icon={<Save className="h-4 w-4" />}>Save Changes</Button>
                                </div>
                            )}
                        </div>
                    </Card>

                    <div className="space-y-3">
                        <button
                            onClick={logout}
                            className="w-full flex items-center justify-center p-4 bg-red-50 text-red-600 font-bold rounded-2xl hover:bg-red-100 transition-colors"
                        >
                            <LogOut className="h-5 w-5 mr-2" />
                            Sign Out
                        </button>
                    </div>

                    <div className="text-center text-xs text-gray-400 pb-4">
                        Version 1.0.0 • FixMyCity Inc.
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CitizenProfile;
