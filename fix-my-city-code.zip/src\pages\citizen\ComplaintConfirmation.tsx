import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { CheckCircle, Home, Plus } from 'lucide-react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';

const ComplaintConfirmation: React.FC = () => {
    const location = useLocation();
    const [complaintId] = React.useState(() => location.state?.complaintId || "CMP-" + Math.floor(Math.random() * 10000));
    const date = new Date().toLocaleDateString();

    return (
        <div className="min-h-screen bg-gray-50 p-6 flex flex-col items-center justify-center text-center relative overflow-hidden">
            {/* Confetti / Decoration */}
            <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
                <div className="absolute top-[20%] left-[20%] w-4 h-4 bg-red-400 rounded-full animate-bounce delay-100"></div>
                <div className="absolute top-[30%] right-[30%] w-3 h-3 bg-blue-400 rounded-sm animate-spin delay-300"></div>
                <div className="absolute bottom-[20%] left-[40%] w-5 h-5 bg-green-400 rounded-full animate-pulse delay-500"></div>
            </div>

            <Card className="w-full max-w-md relative z-10 !border-t-4 !border-t-green-500">
                <div className="mb-6 inline-flex p-4 rounded-full bg-green-50 shadow-inner">
                    <div className="p-3 bg-green-100 rounded-full">
                        <CheckCircle className="h-10 w-10 text-green-600" />
                    </div>
                </div>

                <h1 className="text-3xl font-bold text-gray-900 mb-2">Submitted!</h1>
                <p className="text-gray-500 mb-8">
                    Your complaint has been registered successfully.
                </p>

                <div className="bg-gray-50 rounded-xl p-6 mb-8 text-left space-y-4 border border-gray-100">
                    <div className="flex justify-between items-center border-b border-gray-200 pb-3">
                        <span className="text-sm text-gray-500 font-medium">Complaint ID</span>
                        <span className="font-mono font-bold text-gray-900 bg-white px-2 py-1 rounded border border-gray-200">{complaintId}</span>
                    </div>
                    <div className="flex justify-between items-center border-b border-gray-200 pb-3">
                        <span className="text-sm text-gray-500 font-medium">Date</span>
                        <span className="font-medium text-gray-900">{date}</span>
                    </div>
                    <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-500 font-medium">Status</span>
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                            Expected Resolution: 3 Days
                        </span>
                    </div>
                </div>

                <div className="space-y-3">
                    <Link to="/citizen/dashboard">
                        <Button variant="primary" fullWidth icon={<Home className="h-4 w-4" />}>
                            Back to Dashboard
                        </Button>
                    </Link>
                    <Link to="/citizen/report-issue">
                        <Button variant="outline" fullWidth icon={<Plus className="h-4 w-4" />}>
                            Report Another Issue
                        </Button>
                    </Link>
                </div>
            </Card>
        </div>
    );
};

export default ComplaintConfirmation;
