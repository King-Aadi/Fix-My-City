// Mock AI Service to simulate image recognition

export const analyzeImage = async (file: File): Promise<{ type: string; confidence: number; tags: string[] }> => {
    return new Promise((resolve) => {
        console.log("Analyzing file:", file.name);

        // HEURISTIC AI: Analyze Filename to Determine Type
        const name = file.name.toLowerCase();
        let result = { type: 'General Issue', tags: ['uncategorized', 'issue', 'public', 'city'] };

        if (name.includes('road') || name.includes('pothole') || name.includes('asphalt') || name.includes('crack')) {
            result = { type: 'Pothole', tags: ['asphalt', 'road', 'damage', 'hole', 'infrastructure'] };
        }
        else if (name.includes('water') || name.includes('leak') || name.includes('pipe') || name.includes('drain') || name.includes('sewage')) {
            result = { type: 'Water Leak', tags: ['water', 'pipe', 'leakage', 'plumbing', 'utility'] };
        }
        else if (name.includes('trash') || name.includes('garbage') || name.includes('dump') || name.includes('waste') || name.includes('plastic')) {
            result = { type: 'Garbage Dump', tags: ['waste', 'sanitation', 'health_hazard', 'cleaning_needed'] };
        }
        else if (name.includes('light') || name.includes('lamp') || name.includes('pole') || name.includes('dark')) {
            result = { type: 'Street Light', tags: ['lighting', 'electricity', 'safety', 'night_risk'] };
        }

        setTimeout(() => {
            resolve({
                type: result.type,
                confidence: 0.85 + Math.random() * 0.14, // 85% - 99%
                tags: result.tags
            });
        }, 1500); // 1.5s delay
    });
};
