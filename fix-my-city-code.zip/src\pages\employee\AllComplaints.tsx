import React, { useState } from 'react';
import { Download, Search, Filter, MapPin, Calendar } from 'lucide-react';
import { Link } from 'react-router-dom';
import Card from '../../components/ui/Card';
import Input from '../../components/ui/Input';
import Button from '../../components/ui/Button';
import { db } from '../../services/storage';
import type { Complaint } from '../../services/storage';

const AllComplaints: React.FC = () => {

    const [searchTerm, setSearchTerm] = useState('');

    const [complaints] = useState<Complaint[]>(() => {
        const user = db.getCurrentUser();
        const all = db.getComplaints();
        if (user && user.role === 'employee' && user.zone) {
            return all.filter(c => c.zone === user.zone);
        }
        return all;
    });

    // useEffect removed

    const filteredComplaints = complaints.filter(c =>
        c.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.location.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const handleExport = () => {
        const csvContent = "data:text/csv;charset=utf-8,"
            + "ID,Type,Location,Status,Date\n"
            + complaints.map(row => `${row.id},${row.type},${row.location},${row.status},${row.date}`).join("\n");

        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "complaints_report.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="p-4 max-w-7xl mx-auto space-y-6 pb-24">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Department Overview</h1>
                    <p className="text-gray-500 text-sm">All complaints across zones</p>
                </div>
                <Button
                    variant="outline"
                    icon={<Download className="h-4 w-4" />}
                    onClick={handleExport}
                >
                    Export Report
                </Button>
            </div>

            <Card padding="sm" className="space-y-4">
                <div className="flex gap-4 flex-col md:flex-row">
                    <div className="flex-grow">
                        <Input
                            placeholder="Search records..."
                            icon={<Search className="h-4 w-4" />}
                            className="mb-0"
                            fullWidth
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                    <div className="flex gap-2">
                        <Button variant="outline" icon={<Filter className="h-4 w-4" />}>Filter</Button>
                        <Button variant="outline" icon={<Calendar className="h-4 w-4" />}>Date</Button>
                    </div>
                </div>

                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Complaint Details</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th scope="col" className="relative px-6 py-3"><span className="sr-only">Actions</span></th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {filteredComplaints.length > 0 ? (
                                filteredComplaints.map((complaint) => (
                                    <tr key={complaint.id} className="hover:bg-gray-50 transition-colors group">
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="flex items-center">
                                                <div>
                                                    <div className="text-sm font-bold text-gray-900">{complaint.type}</div>
                                                    <div className="text-xs text-gray-500 font-mono">{complaint.id}</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="flex items-center text-sm text-gray-500">
                                                <MapPin className="h-3 w-3 mr-1 text-gray-400" />
                                                {complaint.location}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            {complaint.date}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${complaint.status === 'Resolved' ? 'bg-green-100 text-green-800' :
                                                complaint.status === 'In Progress' ? 'bg-yellow-100 text-yellow-800' :
                                                    'bg-blue-100 text-blue-800'
                                                }`}>
                                                {complaint.status}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                            <Link
                                                to={`/employee/complaint/${complaint.id}/manage`}
                                                className="text-secondary hover:text-green-900 font-bold"
                                            >
                                                View
                                            </Link>
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan={5} className="px-6 py-10 text-center text-gray-500">
                                        No complaints found
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default AllComplaints;
