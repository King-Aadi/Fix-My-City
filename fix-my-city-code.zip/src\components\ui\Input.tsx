import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
    label?: string;
    error?: string;
    icon?: React.ReactNode;
    fullWidth?: boolean;
}

const Input: React.FC<InputProps> = ({
    label,
    error,
    icon,
    fullWidth = true,
    className = '',
    ...props
}) => {
    const widthClass = fullWidth ? "w-full" : "";

    return (
        <div className={`${widthClass} mb-4`}>
            {label && (
                <label className="block text-sm font-semibold text-gray-700 mb-1.5 ml-1">
                    {label}
                </label>
            )}
            <div className="relative rounded-xl shadow-sm">
                {icon && (
                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <div className="text-gray-400">
                            {icon}
                        </div>
                    </div>
                )}
                <input
                    className={`
            block w-full 
            ${icon ? 'pl-11' : 'pl-4'} pr-4 py-3
            border border-gray-200 rounded-xl
            bg-gray-50 text-gray-900 placeholder-gray-400
            focus:bg-white focus:ring-2 focus:ring-blue-500 focus:border-transparent
            transition-all duration-200 ease-in-out
            sm:text-sm
            ${error ? 'border-red-300 focus:ring-red-500 focus:border-red-500' : ''}
            ${className}
          `}
                    {...props}
                />
            </div>
            {error && (
                <p className="mt-1 text-sm text-red-600 ml-1">{error}</p>
            )}
        </div>
    );
};

export default Input;
