import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { Home, PlusCircle, FileText, User } from 'lucide-react';

const CitizenLayout: React.FC = () => {
    const location = useLocation();

    const isActive = (path: string) => location.pathname === path;

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col">
            <main className="flex-grow pb-16">
                <Outlet />
            </main>

            {/* Bottom Navigation */}
            <nav className="fixed bottom-0 w-full bg-white shadow-lg border-t border-gray-200 z-50">
                <div className="flex justify-around items-center h-16">
                    <Link
                        to="/citizen/dashboard"
                        className={`flex flex-col items-center justify-center w-full h-full ${isActive('/citizen/dashboard') ? 'text-primary' : 'text-gray-500 hover:text-gray-700'
                            }`}
                    >
                        <Home className="h-6 w-6" />
                        <span className="text-xs mt-1 font-medium">Home</span>
                    </Link>

                    <Link
                        to="/citizen/report-issue"
                        className={`flex flex-col items-center justify-center w-full h-full ${isActive('/citizen/report-issue') ? 'text-primary' : 'text-gray-500 hover:text-gray-700'
                            }`}
                    >
                        <PlusCircle className="h-6 w-6" />
                        <span className="text-xs mt-1 font-medium">Report</span>
                    </Link>

                    <Link
                        to="/citizen/complaints"
                        className={`flex flex-col items-center justify-center w-full h-full ${isActive('/citizen/complaints') ? 'text-primary' : 'text-gray-500 hover:text-gray-700'
                            }`}
                    >
                        <FileText className="h-6 w-6" />
                        <span className="text-xs mt-1 font-medium">Complaints</span>
                    </Link>

                    <Link
                        to="/citizen/profile"
                        className={`flex flex-col items-center justify-center w-full h-full ${isActive('/citizen/profile') ? 'text-primary' : 'text-gray-500 hover:text-gray-700'
                            }`}
                    >
                        <User className="h-6 w-6" />
                        <span className="text-xs mt-1 font-medium">Profile</span>
                    </Link>
                </div>
            </nav>
        </div>
    );
};

export default CitizenLayout;
