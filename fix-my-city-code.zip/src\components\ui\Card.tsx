import React from 'react';

interface CardProps {
    children: React.ReactNode;
    className?: string;
    padding?: 'none' | 'sm' | 'md' | 'lg';
    hoverEffect?: boolean;
}

const Card: React.FC<CardProps> = ({
    children,
    className = '',
    padding = 'md',
    hoverEffect = true
}) => {
    const paddings = {
        none: '',
        sm: 'p-4',
        md: 'p-6',
        lg: 'p-8'
    };

    const hoverStyles = hoverEffect
        ? "hover:shadow-xl hover:-translate-y-1 hover:border-blue-100"
        : "";

    return (
        <div className={`bg-white rounded-2xl shadow-sm border border-gray-100 transition-all duration-300 ${paddings[padding]} ${hoverStyles} ${className}`}>
            {children}
        </div>
    );
};

export default Card;
