import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import type { User as UserType } from '../../../services/storage';
import { User, Mail, Phone, Lock, ArrowLeft, UserPlus, FileText } from 'lucide-react';
import Card from '../../../components/ui/Card';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import FaceCapture from '../../../components/ui/FaceCapture';
import { useAuth } from '../../../context/AuthContext';
import { emailService } from '../../../services/email';

const CitizenRegister: React.FC = () => {
    // Steps: 1 = Details + Verify Phone, 3 = Face Registration
    const [step, setStep] = useState(1);

    const [formData, setFormData] = useState({
        fullName: '',
        email: '',
        phone: '',
        password: '',
        confirmPassword: '',
        identityType: 'Aadhar',
        identityNumber: ''
    });

    // OTP State
    const [otpSent, setOtpSent] = useState(false);
    const [enteredOtp, setEnteredOtp] = useState('');
    const [isPhoneVerified, setIsPhoneVerified] = useState(false);
    const [mockOtp, setMockOtp] = useState<string | null>(null);

    // Face State
    const [faceImage, setFaceImage] = useState<string | null>(null);

    const { register, isLoading } = useAuth();
    const navigate = useNavigate();

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const sendOtp = async () => {
        if (!formData.phone) return;

        // Mock OTP System
        const code = Math.floor(1000 + Math.random() * 9000).toString();
        setMockOtp(code);
        setOtpSent(true);
        alert(`[MOCK SMS] Your Verification Code is: ${code}`);
    };

    const verifyOtp = () => {
        if (enteredOtp === mockOtp) {
            setIsPhoneVerified(true);
            alert("Phone Verified Successfully!");
        } else {
            alert("Invalid OTP. Please try again.");
        }
    };

    const handleDetailsNext = (e: React.FormEvent) => {
        e.preventDefault();

        // Basic Validations
        if (!formData.fullName || !formData.email || !formData.phone || !formData.password || !formData.identityNumber) {
            alert("Please fill in all fields");
            return;
        }

        if (formData.password !== formData.confirmPassword) {
            alert("Passwords don't match!");
            return;
        }

        if (!isPhoneVerified) {
            alert("Please verify your phone number first!");
            return;
        }

        // Identity Validation
        if (formData.identityType === 'Aadhar') {
            if (!/^\d{16}$/.test(formData.identityNumber)) {
                alert("Aadhar number must be exactly 16 digits.");
                return;
            }
        } else if (formData.identityType === 'PAN Card') {
            // Regex: 5 letters, 4 numbers, 1 letter (e.g., ABCDE1234F)
            if (!/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(formData.identityNumber)) {
                alert("Invalid PAN Card format. It should be 5 letters, 4 numbers, and 1 letter (e.g., ABCDE1234F).");
                return;
            }
        }

        setStep(2); // Go to Face Registration
    };

    const handleFaceCapture = (_file: File, dataUrl: string) => {
        setFaceImage(dataUrl);
    };

    const handleSubmit = async () => {
        if (!faceImage) {
            alert("Please register your face to proceed.");
            return;
        }

        try {
            await register({
                id: 'CIT-' + Date.now(),
                name: formData.fullName,
                email: formData.email,
                phone: formData.phone,
                role: 'citizen',
                password: formData.password,
                identityType: formData.identityType as UserType['identityType'],
                identityNumber: formData.identityNumber,
                faceVerificationImage: faceImage
            });

            // Send Welcome Email (Real)
            emailService.sendEmail({
                to_name: formData.fullName,
                to_email: formData.email,
                message: "Welcome to Fix My City! Your functionality to report issues is now active. Please verify your identity with face capture when submitting reports."
            });

            alert('Registration Successful! Please login.');
            navigate('/auth/citizen/login');
        } catch (error) {
            alert('Registration Failed: ' + (error as Error).message);
        }
    };

    const renderDetailsForm = () => (
        <form className="space-y-2" onSubmit={handleDetailsNext}>
            <Input
                label="Full Name"
                name="fullName"
                type="text"
                placeholder="John Doe"
                required
                value={formData.fullName}
                onChange={handleChange}
                icon={<User className="h-5 w-5" />}
            />
            <Input
                label="Email Address"
                name="email"
                type="email"
                placeholder="you@example.com"
                required
                value={formData.email}
                onChange={handleChange}
                icon={<Mail className="h-5 w-5" />}
            />
            <div className="space-y-2">
                <div className="flex gap-2 items-end">
                    <div className="flex-1">
                        <Input
                            label="Phone Number"
                            name="phone"
                            type="tel"
                            placeholder="+91 98765 43210"
                            required
                            value={formData.phone}
                            onChange={handleChange}
                            icon={<Phone className="h-5 w-5" />}
                            disabled={isPhoneVerified}
                        />
                    </div>
                    {!isPhoneVerified && (
                        <Button
                            type="button"
                            variant="outline"
                            className="mb-[2px]"
                            onClick={sendOtp}
                            disabled={!formData.phone || otpSent}
                        >
                            {otpSent ? 'Sent' : 'Verify'}
                        </Button>
                    )}
                </div>

                {otpSent && !isPhoneVerified && (
                    <div className="flex gap-2 animate-fade-in bg-blue-50 p-3 rounded-lg border border-blue-100">
                        <input
                            type="text"
                            placeholder="Enter OTP"
                            className="flex-1 rounded-md border-gray-300 text-sm"
                            value={enteredOtp}
                            onChange={(e) => setEnteredOtp(e.target.value)}
                        />
                        <Button type="button" className="py-1 px-3 text-xs" onClick={verifyOtp}>Confirm</Button>
                    </div>
                )}

                {isPhoneVerified && (
                    <p className="text-xs text-green-600 font-bold flex items-center mt-1">
                        ✓ Phone Verified
                    </p>
                )}
            </div>

            {/* Identity Proof Section */}
            <div className="pt-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Identity Proof</label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    <div className="relative">
                        <select
                            name="identityType"
                            value={formData.identityType}
                            onChange={(e) => setFormData({ ...formData, identityType: e.target.value })}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-sm"
                        >
                            <option value="Aadhar">Aadhar Card</option>
                            <option value="Driving License">Driving License</option>
                            <option value="PAN Card">PAN Card</option>
                            <option value="Voter ID">Voter ID</option>
                        </select>
                    </div>
                    <Input
                        name="identityNumber"
                        type="text"
                        placeholder="ID Number"
                        required
                        value={formData.identityNumber}
                        onChange={handleChange}
                        icon={<FileText className="h-5 w-5" />}
                    />
                </div>
            </div>

            <Input
                label="Password"
                name="password"
                type="password"
                placeholder="••••••••"
                required
                value={formData.password}
                onChange={handleChange}
                icon={<Lock className="h-5 w-5" />}
            />
            <Input
                label="Confirm Password"
                name="confirmPassword"
                type="password"
                placeholder="••••••••"
                required
                value={formData.confirmPassword}
                onChange={handleChange}
                icon={<Lock className="h-5 w-5" />}
            />

            <div className="pt-4">
                <Button
                    type="submit"
                    fullWidth
                    icon={<ArrowLeft className="h-5 w-5 rotate-180" />}
                >
                    Next: Face Registration
                </Button>
            </div>
        </form >
    );

    const renderFaceRegistration = () => (
        <div className="space-y-6 animate-fade-in text-center">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-blue-800 text-sm">
                <p className="font-semibold mb-1">Face Registration Required</p>
                To ensure security and authenticity of reports, we need to register your face. This will be used to verify your identity when you submit complaints.
            </div>

            <FaceCapture
                onCapture={handleFaceCapture}
                label="Capture Your Face"
            />

            <div className="flex gap-3 pt-2">
                <Button
                    type="button"
                    variant="outline"
                    fullWidth
                    onClick={() => setStep(1)}
                >
                    Back
                </Button>
                <Button
                    type="button"
                    fullWidth
                    isLoading={isLoading}
                    disabled={!faceImage}
                    onClick={handleSubmit}
                    icon={<UserPlus className="h-5 w-5" />}
                >
                    Complete Registration
                </Button>
            </div>
        </div>
    );

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden">
            {/* Decorative Elements */}
            <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
            <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-purple-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>

            <div className="absolute top-6 left-6 z-10">
                <Link to="/auth/user-type" className="flex items-center text-gray-500 hover:text-gray-900 transition-colors bg-white/50 backdrop-blur-sm px-4 py-2 rounded-full shadow-sm hover:shadow">
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    Back
                </Link>
            </div>

            <div className="sm:mx-auto sm:w-full sm:max-w-md z-10">
                <div className="text-center mb-8">
                    <h2 className="text-3xl font-bold tracking-tight text-gray-900">
                        Create Account
                    </h2>
                    <p className="mt-2 text-sm text-gray-600">
                        {step === 1 ? 'Join your community on FixMyCity' : 'One last step...'}
                    </p>
                </div>

                <Card className="backdrop-blur-xl bg-white/90 shadow-xl border-white/50">
                    <div className="mb-6 flex justify-center">
                        <div className="flex items-center gap-2">
                            <div className={`h-2 w-12 rounded-full ${step >= 1 ? 'bg-blue-600' : 'bg-gray-200'}`}></div>
                            <div className={`h-2 w-12 rounded-full ${step >= 2 ? 'bg-blue-600' : 'bg-gray-200'}`}></div>
                        </div>
                    </div>

                    {step === 1 ? renderDetailsForm() : renderFaceRegistration()}

                    <div className="mt-6 text-center">
                        <p className="text-sm text-gray-600">
                            Already have an account?{' '}
                            <Link to="/auth/citizen/login" className="font-semibold text-blue-600 hover:text-blue-500 hover:underline">
                                Login here
                            </Link>
                        </p>
                    </div>
                </Card>
            </div>
        </div>
    );
};

export default CitizenRegister;
