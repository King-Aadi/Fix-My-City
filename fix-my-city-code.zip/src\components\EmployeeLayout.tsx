import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { Home, Briefcase, List, User } from 'lucide-react';

const EmployeeLayout: React.FC = () => {
    const location = useLocation();

    const isActive = (path: string) => location.pathname === path;

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col font-sans">
            <main className="flex-grow pb-24">
                <Outlet />
            </main>

            {/* Floating Bottom Navigation */}
            <div className="fixed bottom-6 inset-x-0 flex justify-center z-50 px-4">
                <nav className="bg-white/90 backdrop-blur-xl shadow-2xl rounded-full border border-white/50 px-6 py-3 flex items-center space-x-8 max-w-sm w-full justify-between ring-1 ring-black/5">
                    <Link
                        to="/employee/dashboard"
                        className={`flex flex-col items-center justify-center transition-all duration-300 relative group ${isActive('/employee/dashboard') ? 'text-secondary scale-110' : 'text-gray-400 hover:text-gray-600'
                            }`}
                    >
                        <Home className={`h-6 w-6 ${isActive('/employee/dashboard') ? 'fill-current' : ''}`} />
                        {isActive('/employee/dashboard') && (
                            <span className="absolute -bottom-2 w-1 h-1 bg-secondary rounded-full"></span>
                        )}
                    </Link>

                    <Link
                        to="/employee/assigned-complaints"
                        className={`flex flex-col items-center justify-center transition-all duration-300 relative group ${isActive('/employee/assigned-complaints') ? 'text-secondary scale-110' : 'text-gray-400 hover:text-gray-600'
                            }`}
                    >
                        <Briefcase className={`h-6 w-6 ${isActive('/employee/assigned-complaints') ? 'fill-current' : ''}`} />
                        {isActive('/employee/assigned-complaints') && (
                            <span className="absolute -bottom-2 w-1 h-1 bg-secondary rounded-full"></span>
                        )}
                    </Link>

                    <Link
                        to="/employee/all-complaints"
                        className={`flex flex-col items-center justify-center transition-all duration-300 relative group ${isActive('/employee/all-complaints') ? 'text-secondary scale-110' : 'text-gray-400 hover:text-gray-600'
                            }`}
                    >
                        <List className={`h-6 w-6 ${isActive('/employee/all-complaints') ? 'fill-current' : ''}`} />
                        {isActive('/employee/all-complaints') && (
                            <span className="absolute -bottom-2 w-1 h-1 bg-secondary rounded-full"></span>
                        )}
                    </Link>

                    <Link
                        to="/employee/profile"
                        className={`flex flex-col items-center justify-center transition-all duration-300 relative group ${isActive('/employee/profile') ? 'text-secondary scale-110' : 'text-gray-400 hover:text-gray-600'
                            }`}
                    >
                        <User className={`h-6 w-6 ${isActive('/employee/profile') ? 'fill-current' : ''}`} />
                        {isActive('/employee/profile') && (
                            <span className="absolute -bottom-2 w-1 h-1 bg-secondary rounded-full"></span>
                        )}
                    </Link>
                </nav>
            </div>
        </div>
    );
};

export default EmployeeLayout;
