import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldCheck, MapPin, Camera, ChevronRight, Check } from 'lucide-react';

const LandingPage: React.FC = () => {
    return (
        <div className="min-h-screen bg-white flex flex-col font-sans">
            {/* Header */}
            <header className="bg-white/80 backdrop-blur-md shadow-sm z-50 sticky top-0 border-b border-gray-100">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex justify-between h-16 items-center">
                        <div className="flex items-center">
                            <div className="bg-gradient-primary p-2 rounded-lg text-white mr-2">
                                <ShieldCheck className="h-6 w-6" />
                            </div>
                            <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-700 to-blue-500">FixMyCity</span>
                        </div>
                        <div className="flex items-center space-x-4">
                            <Link to="/auth/user-type" className="text-gray-600 hover:text-primary font-medium transition-colors">Log In</Link>
                            <Link
                                to="/auth/user-type"
                                className="bg-gradient-primary text-white px-5 py-2.5 rounded-full hover:shadow-lg hover:opacity-90 transition-all font-medium flex items-center transform hover:-translate-y-0.5"
                            >
                                Get Started <ChevronRight className="ml-1 h-4 w-4" />
                            </Link>
                        </div>
                    </div>
                </div>
            </header>

            {/* Hero Section */}
            <main className="flex-grow">
                <div className="relative bg-white overflow-hidden">
                    <div className="max-w-7xl mx-auto">
                        <div className="relative z-10 pb-8 bg-white sm:pb-16 md:pb-20 lg:max-w-2xl lg:w-full lg:pb-28 xl:pb-32 pt-20">
                            <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                                <div className="sm:text-center lg:text-left">
                                    <h1 className="text-4xl tracking-tight font-extrabold text-gray-900 sm:text-5xl md:text-6xl animate-fade-in">
                                        <span className="block xl:inline">Report civic issues</span>{' '}
                                        <span className="block text-transparent bg-clip-text bg-gradient-primary mt-2">empower your city</span>
                                    </h1>
                                    <p className="mt-4 text-base text-gray-500 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl lg:mx-auto animate-slide-up" style={{ animationDelay: '0.1s' }}>
                                        Transform your neighborhood with FixMyCity. Report potholes, garbage, and infrastructure issues instantly. We connect citizens directly with municipal authorities.
                                    </p>
                                    <div className="mt-8 sm:mt-12 sm:flex sm:justify-center lg:justify-start animate-slide-up" style={{ animationDelay: '0.2s' }}>
                                        <div className="rounded-md shadow">
                                            <Link
                                                to="/auth/user-type"
                                                className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-full text-white bg-gradient-primary hover:shadow-xl transition-all md:py-4 md:text-lg md:px-10"
                                            >
                                                Report an Issue
                                            </Link>
                                        </div>
                                        <div className="mt-3 sm:mt-0 sm:ml-3">
                                            <Link
                                                to="/auth/user-type"
                                                className="w-full flex items-center justify-center px-8 py-3 border border-gray-200 text-base font-medium rounded-full text-primary bg-white hover:bg-gray-50 md:py-4 md:text-lg md:px-10 hover:shadow-md transition-all"
                                            >
                                                Employee Login
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Animated Background Graphic */}
                    <div className="lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/2 bg-blue-50 flex items-center justify-center overflow-hidden">
                        <div className="relative w-full h-full flex items-center justify-center">
                            <div className="absolute w-[500px] h-[500px] bg-blue-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse top-0 left-0"></div>
                            <div className="absolute w-[500px] h-[500px] bg-purple-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse bottom-0 right-0"></div>
                            <div className="z-10 relative bg-white/30 backdrop-blur-lg p-8 rounded-2xl border border-white/50 shadow-2xl transform rotate-3 hover:rotate-0 transition-transform duration-500">
                                <div className="flex items-center space-x-3 mb-4">
                                    <div className="h-3 w-3 rounded-full bg-red-400"></div>
                                    <div className="h-3 w-3 rounded-full bg-yellow-400"></div>
                                    <div className="h-3 w-3 rounded-full bg-green-400"></div>
                                </div>
                                <div className="bg-white p-4 rounded-lg shadow-inner w-64 space-y-3">
                                    <div className="h-2 bg-gray-200 rounded w-3/4"></div>
                                    <div className="h-2 bg-gray-200 rounded w-1/2"></div>
                                    <div className="h-24 bg-blue-100 rounded-lg flex items-center justify-center">
                                        <MapPin className="text-primary h-8 w-8" />
                                    </div>
                                    <div className="flex justify-between items-center bg-green-50 p-2 rounded border border-green-100">
                                        <span className="text-xs text-green-700 font-medium">Issue Resolved</span>
                                        <Check className="h-4 w-4 text-green-600" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Feature Highlights */}
                <div className="py-20 bg-gray-50">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <div className="lg:text-center mb-12">
                            <h2 className="text-base text-primary font-bold tracking-wide uppercase">Why FixMyCity?</h2>
                            <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
                                Smarter civic management
                            </p>
                        </div>

                        <div className="mt-10">
                            <dl className="space-y-10 md:space-y-0 md:grid md:grid-cols-2 md:gap-x-12 md:gap-y-12">
                                <div className="relative bg-white p-6 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
                                    <dt>
                                        <div className="absolute flex items-center justify-center h-12 w-12 rounded-xl bg-secondary text-white shadow-lg">
                                            <Camera className="h-6 w-6" aria-hidden="true" />
                                        </div>
                                        <p className="ml-16 text-xl leading-6 font-bold text-gray-900">AI-Powered Reporting</p>
                                    </dt>
                                    <dd className="mt-2 ml-16 text-base text-gray-500 leading-relaxed">
                                        Simply take a photo. Our advanced AI automatically classifies the issue (e.g., Pothole, Garbage) and generates a detailed description for you in seconds.
                                    </dd>
                                </div>

                                <div className="relative bg-white p-6 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
                                    <dt>
                                        <div className="absolute flex items-center justify-center h-12 w-12 rounded-xl bg-primary text-white shadow-lg">
                                            <MapPin className="h-6 w-6" aria-hidden="true" />
                                        </div>
                                        <p className="ml-16 text-xl leading-6 font-bold text-gray-900">Verified Location Data</p>
                                    </dt>
                                    <dd className="mt-2 ml-16 text-base text-gray-500 leading-relaxed">
                                        We capture precise GPS coordinates and require face verification to ensure every report is authentic and actionable by municipal teams.
                                    </dd>
                                </div>
                            </dl>
                        </div>
                    </div>
                </div>
            </main>

            {/* Footer */}
            <footer className="bg-gray-900 text-white py-12 border-t border-gray-800">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center">
                    <div className="mb-4 md:mb-0">
                        <div className="flex items-center">
                            <ShieldCheck className="h-6 w-6 text-blue-500" />
                            <span className="ml-2 text-xl font-bold tracking-wider">FixMyCity</span>
                        </div>
                        <p className="text-gray-500 text-sm mt-2">Empowering citizens, building better cities.</p>
                    </div>
                    <div className="flex space-x-8 text-sm text-gray-400">
                        <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
                        <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
                        <a href="#" className="hover:text-white transition-colors">Contact Support</a>
                    </div>
                </div>
                <div className="text-center mt-8 text-gray-600 text-xs">
                    © 2026 FixMyCity Inc. All rights reserved.
                </div>
            </footer>
        </div>
    );
};

export default LandingPage;
