import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { AlertCircle, CheckCircle, Clock } from 'lucide-react';
import Card from '../../components/ui/Card';
import { db } from '../../services/storage';
import { useComplaints } from '../../hooks/useComplaints';

const EmployeeDashboard: React.FC = () => {
    const { complaints: allComplaints } = useComplaints();
    const user = db.getCurrentUser();
    const [now] = useState(() => Date.now());

    // Derived stats from Reactive Data
    const relevantComplaints = React.useMemo(() => {
        return (user && user.role === 'employee' && user.zone)
            ? allComplaints.filter(c => c.zone === user.zone)
            : allComplaints;
    }, [allComplaints, user]);

    const recentAssigned = React.useMemo(() => {
        return relevantComplaints
            .filter(c => c.status !== 'Resolved')
            .slice(0, 5);
    }, [relevantComplaints]);

    const stats = {
        assigned: relevantComplaints.filter(c => c.status === 'Assigned').length,
        pending: relevantComplaints.filter(c => c.status === 'In Progress' || c.status === 'Submitted').length,
        resolved: relevantComplaints.filter(c => c.status === 'Resolved').length,
        overdue: relevantComplaints.filter(c => c.status !== 'Resolved' && new Date(c.date).getTime() < now - 7 * 24 * 60 * 60 * 1000).length
    };

    return (
        <div className="px-4 py-8 max-w-7xl mx-auto space-y-8">
            {/* Header */}
            <div className="flex justify-between items-end">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
                    <p className="text-gray-600 mt-1">Hello, {user?.name || 'Officer'} ({user?.department || 'Department'}) - <span className="font-semibold text-emerald-600">{user?.zone ? `${user.zone} Zone` : 'All Zones'}</span></p>
                </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <Card className="border-l-4 border-l-blue-500 bg-blue-50/50" padding="md">
                    <div className="flex justify-between items-start mb-2">
                        <span className="text-gray-500 text-xs font-bold uppercase tracking-wide">Assigned</span>
                        <div className="p-1.5 bg-blue-100 rounded-lg">
                            <Clock className="h-4 w-4 text-blue-600" />
                        </div>
                    </div>
                    <div className="text-3xl font-bold text-gray-900">{stats.assigned}</div>
                </Card>

                <Card className="border-l-4 border-l-red-500 bg-red-50/50" padding="md">
                    <div className="flex justify-between items-start mb-2">
                        <span className="text-gray-500 text-xs font-bold uppercase tracking-wide">Overdue</span>
                        <div className="p-1.5 bg-red-100 rounded-lg">
                            <AlertCircle className="h-4 w-4 text-red-600" />
                        </div>
                    </div>
                    <div className="text-3xl font-bold text-gray-900">{stats.overdue}</div>
                </Card>

                <Card className="border-l-4 border-l-green-500 bg-green-50/50" padding="md">
                    <div className="flex justify-between items-start mb-2">
                        <span className="text-gray-500 text-xs font-bold uppercase tracking-wide">Resolved</span>
                        <div className="p-1.5 bg-green-100 rounded-lg">
                            <CheckCircle className="h-4 w-4 text-green-600" />
                        </div>
                    </div>
                    <div className="text-3xl font-bold text-gray-900">{stats.resolved}</div>
                </Card>

                <Card className="border-l-4 border-l-yellow-500 bg-yellow-50/50" padding="md">
                    <div className="flex justify-between items-start mb-2">
                        <span className="text-gray-500 text-xs font-bold uppercase tracking-wide">Pending</span>
                        <div className="p-1.5 bg-yellow-100 rounded-lg">
                            <Clock className="h-4 w-4 text-yellow-600" />
                        </div>
                    </div>
                    <div className="text-3xl font-bold text-gray-900">{stats.pending}</div>
                </Card>
            </div>

            {/* Detailed task list */}
            <div>
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-lg font-bold text-gray-900">Priority Tasks</h2>
                    <Link to="/employee/assigned-complaints" className="text-secondary hover:text-green-700 text-sm font-medium transition-colors">
                        View All
                    </Link>
                </div>

                <div className="space-y-4">
                    {recentAssigned.length > 0 ? (
                        recentAssigned.map((complaint) => (
                            <Link
                                key={complaint.id}
                                to={`/employee/complaint/${complaint.id}/manage`}
                                className="block group"
                            >
                                <Card className="hover:border-green-300 transition-all border-l-4 border-l-transparent hover:border-l-green-500" padding="md">
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <div className="flex items-center space-x-2 mb-1">
                                                <h3 className="font-bold text-gray-900 group-hover:text-secondary transition-colors">{complaint.type}</h3>
                                                {complaint.priority === 'High' && (
                                                    <span className="bg-red-100 text-red-700 text-[10px] px-2 py-0.5 rounded-full font-bold uppercase">High Priority</span>
                                                )}
                                            </div>
                                            <p className="text-sm text-gray-500">{complaint.location}</p>
                                        </div>
                                        <div className="text-right">
                                            <span className={`inline-block px-2.5 py-1 rounded-lg text-xs font-bold ${complaint.status === 'In Progress' ? 'bg-yellow-100 text-yellow-800' : 'bg-blue-100 text-blue-800'
                                                }`}>
                                                {complaint.status}
                                            </span>
                                            <p className="text-xs text-gray-400 mt-2 font-medium">Due soon</p>
                                        </div>
                                    </div>
                                </Card>
                            </Link>
                        ))
                    ) : (
                        <div className="text-center py-8 text-gray-500">No active tasks found.</div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default EmployeeDashboard;
