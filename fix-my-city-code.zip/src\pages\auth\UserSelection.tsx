import React from 'react';
import { Link } from 'react-router-dom';
import { User, Briefcase, ArrowLeft } from 'lucide-react';

const UserSelection: React.FC = () => {
    return (
        <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden">
            {/* Background Decoration */}
            <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
                <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
                <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-green-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
            </div>

            <div className="absolute top-6 left-6 z-20">
                <Link to="/" className="flex items-center text-gray-600 hover:text-primary transition-colors font-medium">
                    <ArrowLeft className="h-5 w-5 mr-1" />
                    Back to Home
                </Link>
            </div>

            <div className="sm:mx-auto sm:w-full sm:max-w-md z-10">
                <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900 tracking-tight">
                    Welcome to FixMyCity
                </h2>
                <p className="mt-2 text-center text-sm text-gray-600">
                    Select your role to continue
                </p>
            </div>

            <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-4xl px-4 z-10">
                <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
                    {/* Citizen Card */}
                    <Link to="/auth/citizen/login" className="group">
                        <div className="bg-white rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 p-8 flex flex-col items-center text-center h-full relative overflow-hidden">
                            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-primary transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left"></div>

                            <div className="h-24 w-24 rounded-full bg-blue-50 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                                <User className="h-10 w-10 text-primary" />
                            </div>
                            <h3 className="text-2xl font-bold text-gray-900 mb-2">Citizen</h3>
                            <p className="text-gray-500 mb-8 leading-relaxed">
                                Report issues in your neighborhood, track their status, and help improve your community.
                            </p>
                            <div className="mt-auto">
                                <span className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-full text-white bg-primary group-hover:bg-blue-700 transition-colors w-full shadow-md">
                                    Login as Citizen
                                </span>
                            </div>
                        </div>
                    </Link>

                    {/* Employee Card */}
                    <Link to="/auth/employee/login" className="group">
                        <div className="bg-white rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 p-8 flex flex-col items-center text-center h-full relative overflow-hidden">
                            <div className="absolute top-0 left-0 w-full h-1 bg-secondary transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left"></div>

                            <div className="h-24 w-24 rounded-full bg-green-50 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                                <Briefcase className="h-10 w-10 text-secondary" />
                            </div>
                            <h3 className="text-2xl font-bold text-gray-900 mb-2">Municipal Employee</h3>
                            <p className="text-gray-500 mb-8 leading-relaxed">
                                Access your assigned tasks, update complaint status, and manage departmental workflows.
                            </p>
                            <div className="mt-auto">
                                <span className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-full text-white bg-secondary group-hover:bg-green-700 transition-colors w-full shadow-md">
                                    Login as Employee
                                </span>
                            </div>
                        </div>
                    </Link>
                </div>
            </div>
        </div>
    );
};

export default UserSelection;
