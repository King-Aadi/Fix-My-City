import React, { useState } from 'react';
import { MapPin, Navigation } from 'lucide-react';
import Button from '../../components/ui/Button';
import GoogleMapPicker from '../../components/ui/GoogleMapPicker';

interface LocationStepProps {
    onNext: (data: { location: string; coordinates: { lat: number; lng: number } }) => void;
}

const LocationStep: React.FC<LocationStepProps> = ({ onNext }) => {
    const [loading, setLoading] = useState(false);
    const [address, setAddress] = useState('');
    const [coordinates, setCoordinates] = useState<{ lat: number; lng: number } | null>(null);

    const getLocation = () => {
        setLoading(true);
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const newCoords = {
                        lat: position.coords.latitude,
                        lng: position.coords.longitude,
                    };
                    setCoordinates(newCoords);
                    setAddress(`Lat: ${newCoords.lat.toFixed(4)}, Lng: ${newCoords.lng.toFixed(4)}`);
                    setLoading(false);
                },
                (error) => {
                    console.error(error);
                    alert('Unable to retrieve your location. Please ensure location services are enabled.');
                    setLoading(false);
                    // Fallback to default city center
                    setCoordinates({ lat: 12.9716, lng: 77.5946 });
                    setAddress("Default Location (Please pin exact spot)");
                }
            );
        } else {
            alert('Geolocation is not supported by your browser');
            setLoading(false);
        }
    };

    const handleMapSelect = (lat: number, lng: number) => {
        setCoordinates({ lat, lng });
        setAddress(`Pinned: ${lat.toFixed(4)}, ${lng.toFixed(4)}`);
    };

    const handleNext = () => {
        if (coordinates && address) {
            // Refine address string for Duplicate Checker
            // In a real app we would reverse geocode here
            const finalAddress = address.includes("Pinned") ? `Custom Location (${coordinates.lat.toFixed(3)}, ${coordinates.lng.toFixed(3)})` : address;
            onNext({ location: finalAddress, coordinates });
        } else {
            alert('Please detect or pin your location');
        }
    };

    return (
        <div className="space-y-6 animate-fade-in">
            <div className="text-center space-y-2">
                <h2 className="text-2xl font-bold text-gray-900">Where is the issue?</h2>
                <p className="text-gray-500">Pin the exact location on the map.</p>
            </div>

            <div className="bg-gray-50 h-80 rounded-2xl border-2 border-gray-200 overflow-hidden relative shadow-inner">
                {coordinates ? (
                    <GoogleMapPicker
                        key={`${coordinates.lat}-${coordinates.lng}`}
                        initialLat={coordinates.lat}
                        initialLng={coordinates.lng}
                        onLocationSelect={handleMapSelect}
                    />
                ) : (
                    <div className="h-full flex flex-col items-center justify-center text-gray-400">
                        <MapPin className="h-12 w-12 mb-3 opacity-30" />
                        <p>Tap "Detect Location" to load map</p>
                    </div>
                )}
            </div>

            <div className="text-center">
                {address && <p className="text-sm font-medium text-gray-700 bg-blue-50 py-2 px-4 rounded-full inline-block">{address}</p>}
            </div>

            <div className="space-y-4 pt-2">
                {!coordinates && (
                    <Button
                        onClick={getLocation}
                        disabled={loading}
                        variant="outline"
                        fullWidth
                        isLoading={loading}
                        icon={<Navigation className="h-5 w-5" />}
                    >
                        Detect Current Location
                    </Button>
                )}

                {coordinates && (
                    <div className="flex gap-3">
                        <Button
                            onClick={getLocation}
                            disabled={loading}
                            variant="outline"
                            className="w-1/3"
                            icon={<Navigation className="h-4 w-4" />}
                        >
                            Reset
                        </Button>
                        <Button
                            onClick={handleNext}
                            fullWidth
                            variant="primary"
                            className="w-2/3"
                        >
                            Confirm Location
                        </Button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default LocationStep;
