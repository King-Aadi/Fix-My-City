import emailjs from '@emailjs/browser';

interface EmailData {
    to_name: string;
    to_email: string;
    message?: string;
}

export const emailService = {
    sendEmail: async (data: EmailData) => {
        const serviceId = import.meta.env.VITE_EMAILJS_SERVICE_ID;
        const templateId = import.meta.env.VITE_EMAILJS_TEMPLATE_ID;
        const publicKey = import.meta.env.VITE_EMAILJS_PUBLIC_KEY;

        if (!serviceId || !templateId || !publicKey) {
            console.warn("EmailJS configuration missing. Falling back to MOCK email service.");

            // Simulate network delay
            await new Promise(resolve => setTimeout(resolve, 1000));

            // Log to console as the "Email"
            console.group('📧 MOCK EMAIL SENT');
            console.log(`To: ${data.to_name} <${data.to_email}>`);
            console.log(`Subject: FixMyCity Notification`);
            console.log(`Message:\n${data.message}`);
            console.groupEnd();

            // Optional: Alert for visibility ensuring user knows "it blocked"
            // alert(`[Demo Mode] Email sent to ${data.to_email}`);
            return;
        }

        try {
            const response = await emailjs.send(
                serviceId,
                templateId,
                {
                    to_name: data.to_name,
                    to_email: data.to_email,
                    message: data.message || "Thank you for registering with Fix My City!",
                },
                publicKey
            );
            console.log('SUCCESS!', response.status, response.text);
        } catch (error) {
            console.error('FAILED...', error);
            // Fallback to mock on error too, so flow isn't broken
            console.log("[Fallback] Email content:", data.message);
        }
    }
};
