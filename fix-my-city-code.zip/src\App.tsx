import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LandingPage from './pages/LandingPage';
import UserSelection from './pages/auth/UserSelection';
import CitizenLogin from './pages/auth/citizen/Login';
import CitizenRegister from './pages/auth/citizen/Register';
import EmployeeLogin from './pages/auth/employee/Login';
import EmployeeRegister from './pages/auth/employee/Register';
import CitizenLayout from './components/CitizenLayout';
import CitizenDashboard from './pages/citizen/Dashboard';
import ReportIssue from './pages/citizen/ReportIssue';
import ComplaintConfirmation from './pages/citizen/ComplaintConfirmation';
import ComplaintsList from './pages/citizen/ComplaintsList';
import ComplaintDetails from './pages/citizen/ComplaintDetails';
import CitizenProfile from './pages/citizen/Profile';
import EmployeeLayout from './components/EmployeeLayout';
import EmployeeDashboard from './pages/employee/Dashboard';
import AssignedComplaints from './pages/employee/AssignedComplaints';
import ManageComplaint from './pages/employee/ManageComplaint';
import AllComplaints from './pages/employee/AllComplaints';
import EmployeeProfile from './pages/employee/Profile';

import { AuthProvider } from './context/AuthContext';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-gray-50">
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/auth/user-type" element={<UserSelection />} />
            <Route path="/auth/citizen/login" element={<CitizenLogin />} />
            <Route path="/auth/citizen/register" element={<CitizenRegister />} />
            {/* Employee Routes Placeholders */}
            <Route path="/auth/employee/login" element={<EmployeeLogin />} />
            <Route path="/auth/employee/register" element={<EmployeeRegister />} />

            {/* Citizen Routes */}
            <Route path="/citizen" element={<CitizenLayout />}>
              <Route path="dashboard" element={<CitizenDashboard />} />
              <Route path="report-issue" element={<ReportIssue />} />
              <Route path="complaint-confirmation" element={<ComplaintConfirmation />} />
              <Route path="complaints" element={<ComplaintsList />} />
              <Route path="complaint/:id" element={<ComplaintDetails />} />
              <Route path="profile" element={<CitizenProfile />} />
            </Route>

            {/* Employee Routes */}
            <Route path="/employee" element={<EmployeeLayout />}>
              <Route path="dashboard" element={<EmployeeDashboard />} />
              <Route path="assigned-complaints" element={<AssignedComplaints />} />
              <Route path="complaint/:id/manage" element={<ManageComplaint />} />
              <Route path="all-complaints" element={<AllComplaints />} />
              <Route path="profile" element={<EmployeeProfile />} />
            </Route>
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
