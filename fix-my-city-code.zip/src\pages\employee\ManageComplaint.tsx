import React, { useState, useRef, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, MapPin, Camera, AlertTriangle, Send, CheckCircle, RefreshCw, X, User, Briefcase } from 'lucide-react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { db } from '../../services/storage';
import { emailService } from '../../services/email';
import type { Complaint } from '../../services/storage';

const ManageComplaint: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();

    // Initialize state from DB immediately
    const [complaint, setComplaint] = useState<Complaint | null>(() => {
        if (!id) return null;
        const all = db.getComplaints();
        return all.find(c => c.id === id) || null;
    });

    const [status, setStatus] = useState<string>(() => {
        return complaint?.status || 'In Progress';
    });

    const [note, setNote] = useState('');
    const [isUpdating, setIsUpdating] = useState(false);

    // Camera State
    const [isCameraOpen, setIsCameraOpen] = useState(false);
    const [capturedImage, setCapturedImage] = useState<string | null>(null);
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const streamRef = useRef<MediaStream | null>(null);

    const stopCamera = () => {
        if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop());
            streamRef.current = null;
        }
        setIsCameraOpen(false);
    };

    useEffect(() => {
        if (complaint) {
            // Access Control Check
            const user = db.getCurrentUser();
            if (user && user.role === 'employee' && user.zone && complaint.zone && user.zone !== complaint.zone) {
                alert('Unauthorized: This complaint belongs to a different zone.');
                navigate('/employee/dashboard');
                return;
            }
        }
        return () => {
            stopCamera();
        };
    }, [complaint, navigate]);


    const startCamera = async () => {
        setCapturedImage(null);
        setIsCameraOpen(true);
        try {
            const stream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: 'environment' }
            });
            streamRef.current = stream;
            if (videoRef.current) {
                videoRef.current.srcObject = stream;
            }
        } catch (err) {
            console.error("Error accessing camera:", err);
            alert("Unable to access camera or permission denied.");
            setIsCameraOpen(false);
        }
    };

    // stopCamera moved up

    const capturePhoto = () => {
        if (videoRef.current && canvasRef.current) {
            const video = videoRef.current;
            const canvas = canvasRef.current;
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const context = canvas.getContext('2d');
            if (context) {
                context.drawImage(video, 0, 0, canvas.width, canvas.height);
                const imageDataUrl = canvas.toDataURL('image/jpeg');
                setCapturedImage(imageDataUrl);
                stopCamera();
            }
        }
    };

    const handleUpdate = () => {
        if (!complaint) return;
        setIsUpdating(true);

        // Save to DB
        db.updateComplaint(complaint.id, {
            status: status as unknown as Complaint['status'],
            // In a real app we would append to an updates array
            updates: [
                ...(complaint.updates || []),
                {
                    date: new Date().toISOString(),
                    status,
                    note,
                    proof: capturedImage || undefined
                }
            ]
        });

        // Send Email Notification (if status changed or note added)
        // Find user email (In real app, we fetch user by complaint.userId)
        // For local demo, we assume we can fetch user or just send to 'Current User' if they are the one viewing?
        // Actually, employees are managing complaints for citizens. We need the citizen's email.
        const citizen = db.getUsers().find(u => u.id === complaint.userId);
        if (citizen?.email) {
            let emailSubject = `Complaint Update: ${complaint.id}`;
            let emailBody = `Dear ${citizen.name},\n\nThe status of your complaint (ID: ${complaint.id}) has been updated to: ${status}.\n\nNote: ${note || 'No additional notes.'}`;

            if (status === 'Resolved') {
                emailSubject = `✅ Complaint Resolved: ${complaint.id}`;
                emailBody = `Dear ${citizen.name},\n\nWe are pleased to inform you that your complaint regarding "${complaint.type}" at "${complaint.location}" has been SUCCESSFULLY RESOLVED.\n\nOfficer's Note: ${note || 'Work completed.'}\n\nPlease check your dashboard to view the proof of resolution.\n\nThank you for helping us Fix My City!\n\nBest Regards,\nMunicipal Corporation`;
            } else if (status === 'Rejected') {
                emailSubject = `❌ Complaint Rejected: ${complaint.id}`;
                emailBody = `Dear ${citizen.name},\n\nYour complaint regarding "${complaint.type}" has been reviewed and rejected.\n\nReason: ${note || 'Does not meet criteria or already resolved.'}\n\nIf you believe this is an error, please file a new report with more details.\n\nRegards,\nFixMyCity Team`;
            } else if (status === 'Assigned') {
                emailSubject = `👷 Officer Assigned: ${complaint.id}`;
                emailBody = `Dear ${citizen.name},\n\nAn officer has been assigned to your complaint.\n\nAssigned To: ${complaint.assignedTo || 'Field Worker'}\n\nWork will commence shortly.\n\nRegards,\nFixMyCity Team`;
            }

            emailService.sendEmail({
                to_name: citizen.name,
                to_email: citizen.email,
                message: `${emailSubject}\n\n${emailBody}`
            });
        }

        setTimeout(() => {
            setIsUpdating(false);
            stopCamera();
            navigate('/employee/all-complaints');
        }, 1000);
    };

    if (!complaint) {
        return <div className="p-8 text-center text-gray-500">Complaint not found or loading...</div>;
    }

    return (
        <div className="min-h-screen bg-gray-50 pb-20">
            <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-10 border-b border-gray-100">
                <div className="px-4 h-16 flex items-center max-w-3xl mx-auto">
                    <button onClick={() => navigate(-1)} className="mr-4 p-2 -ml-2 rounded-full hover:bg-gray-100 transition-colors text-gray-600">
                        <ArrowLeft className="h-5 w-5" />
                    </button>
                    <h1 className="text-lg font-bold text-gray-900">Manage Complaint</h1>
                </div>
            </header>

            <div className="max-w-3xl mx-auto p-4 space-y-6">
                {/* Priority Alert */}
                <div className="bg-gradient-to-r from-red-50 to-orange-50 border border-red-100 text-red-800 px-4 py-3 rounded-xl flex items-start shadow-sm">
                    <div className="bg-red-100 p-1.5 rounded-full mr-3 mt-0.5">
                        <AlertTriangle className="h-5 w-5 text-red-600" />
                    </div>
                    <div>
                        <p className="font-bold text-sm">Priority Attention Needed</p>
                        <p className="text-xs text-red-700 mt-1">Marked <span className="font-bold uppercase">{complaint.priority || 'Medium'}</span>.</p>
                    </div>
                </div>

                {/* Complaint Info Card */}
                <div className="rounded-2xl overflow-hidden shadow-lg bg-white">
                    <div className="h-56 relative group">
                        {complaint.image ? (
                            <img src={complaint.image} alt="Issue" className="w-full h-full object-cover" />
                        ) : (
                            <div className="w-full h-full bg-gray-200 flex items-center justify-center text-gray-400">No Image</div>
                        )}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                        <div className="absolute bottom-4 left-4 text-white">
                            <h2 className="text-2xl font-bold">{complaint.type}</h2>
                        </div>
                    </div>

                    <div className="p-6">
                        <p className="text-gray-700 leading-relaxed mb-6 border-b border-gray-100 pb-6">{complaint.description}</p>
                        <div className="space-y-3">
                            <div className="flex items-start">
                                <MapPin className="h-5 w-5 mr-3 text-gray-400" />
                                <span className="text-sm font-medium text-gray-900">{complaint.location}</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Action Panel */}
                <Card className="border-t-4 border-t-secondary space-y-8">
                    {/* Assignment Section (Zonal Head View) */}
                    <div>
                        <h3 className="font-bold text-gray-900 mb-4 flex items-center">
                            <Briefcase className="h-5 w-5 mr-2 text-secondary" />
                            Assign Task (Zonal Head)
                        </h3>
                        <div className="bg-gray-50 p-4 rounded-xl border border-gray-200">
                            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">Select Team Member</label>
                            <select
                                className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-secondary focus:ring focus:ring-secondary focus:ring-opacity-50"
                                value={complaint.assignedTo || ''}
                                onChange={(e) => {
                                    // In real app, this would be a separate API call. 
                                    // Here we update local state and db immediately for verified persistence
                                    const val = e.target.value;
                                    setComplaint(prev => prev ? ({ ...prev, assignedTo: val, status: 'Assigned' }) : null);
                                    setStatus('Assigned'); // Auto-switch status
                                    db.updateComplaint(complaint.id, { assignedTo: val, status: 'Assigned' });
                                }}
                            >
                                <option value="">-- Unassigned --</option>
                                <optgroup label="Road Maintenance Team">
                                    <option value="Ramesh (Roads) - 9876500001">Ramesh (Roads) - Ph: 9876500001</option>
                                    <option value="Suresh (Potholes) - 9876500002">Suresh (Potholes) - Ph: 9876500002</option>
                                </optgroup>
                                <optgroup label="Water Supply Team">
                                    <option value="Mahesh (Plumbing) - 9876500003">Mahesh (Plumbing) - Ph: 9876500003</option>
                                    <option value="Ganesh (Sewage) - 9876500004">Ganesh (Sewage) - Ph: 9876500004</option>
                                </optgroup>
                                <optgroup label="Sanitation Team">
                                    <option value="Raju (Waste) - 9876500005">Raju (Waste) - Ph: 9876500005</option>
                                </optgroup>
                            </select>
                            {complaint.assignedTo && (
                                <div className="mt-3 flex items-start bg-blue-50 p-3 rounded-lg text-sm text-blue-800">
                                    <User className="h-4 w-4 mr-2 mt-0.5" />
                                    <div>
                                        <span className="font-bold">Assigned to:</span> {complaint.assignedTo}
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="border-t border-gray-100 pt-6">
                        <h3 className="font-bold text-gray-900 mb-6 flex items-center">
                            <CheckCircle className="h-5 w-5 mr-2 text-secondary" />
                            Update Status (Field Worker)
                        </h3>
                    </div>

                    <div className="space-y-6">
                        <div className="grid grid-cols-4 gap-2">
                            {['Assigned', 'In Progress', 'Resolved', 'Rejected'].map((option) => (
                                <button
                                    key={option}
                                    onClick={() => setStatus(option)}
                                    className={`py-2 px-1 text-xs font-bold rounded-lg border-2 transition-all ${status === option
                                        ? 'border-secondary bg-green-50 text-secondary shadow-sm'
                                        : 'border-gray-100 bg-white text-gray-500 hover:border-gray-200'
                                        }`}
                                >
                                    {option}
                                </button>
                            ))}
                        </div>

                        <div>
                            <label className="block text-sm font-bold text-gray-700 mb-2">Progress Note</label>
                            <textarea
                                rows={3}
                                className="block w-full border-gray-200 rounded-xl bg-gray-50 focus:bg-white focus:ring-2 focus:ring-secondary focus:border-transparent p-4 text-sm resize-none"
                                placeholder="Details..."
                                value={note}
                                onChange={(e) => setNote(e.target.value)}
                            />
                        </div>

                        {status === 'Resolved' && (
                            <div className="space-y-4">
                                <label className="block text-sm font-bold text-gray-700">Proof of Resolution</label>

                                {!isCameraOpen && !capturedImage && (
                                    <div
                                        onClick={startCamera}
                                        className="bg-gray-50 border-2 border-dashed border-gray-200 rounded-xl p-8 text-center cursor-pointer hover:border-secondary hover:bg-green-50/50 transition-colors group"
                                    >
                                        <div className="bg-white p-3 rounded-full shadow-sm inline-block mb-3 group-hover:scale-110 transition-transform">
                                            <Camera className="h-6 w-6 text-secondary" />
                                        </div>
                                        <p className="font-medium text-gray-900">Take Photo Proof</p>
                                    </div>
                                )}

                                {isCameraOpen && (
                                    <div className="relative rounded-xl overflow-hidden bg-black aspect-video flex items-center justify-center">
                                        <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                                        <button
                                            onClick={capturePhoto}
                                            className="absolute bottom-4 bg-white rounded-full p-4 shadow-lg hover:bg-gray-100 transition-transform hover:scale-110"
                                        >
                                            <div className="h-4 w-4 bg-red-600 rounded-full"></div>
                                        </button>
                                        <button
                                            onClick={stopCamera}
                                            className="absolute top-4 right-4 bg-black/50 p-2 rounded-full text-white"
                                        >
                                            <X className="h-5 w-5" />
                                        </button>
                                    </div>
                                )}

                                {capturedImage && (
                                    <div className="relative rounded-xl overflow-hidden aspect-video border-2 border-green-500 shadow-md">
                                        <img src={capturedImage} alt="Captured Proof" className="w-full h-full object-cover" />
                                        <div className="absolute top-2 right-2 flex gap-2">
                                            <button
                                                onClick={startCamera}
                                                className="bg-white/90 p-2 rounded-full shadow hover:bg-white text-gray-700"
                                            >
                                                <RefreshCw className="h-4 w-4" />
                                            </button>
                                        </div>
                                        <div className="absolute bottom-0 inset-x-0 bg-black/60 p-2 text-white text-xs text-center">
                                            Proof Captured
                                        </div>
                                    </div>
                                )}
                                <canvas ref={canvasRef} className="hidden" />
                            </div>
                        )}

                        <Button
                            onClick={handleUpdate}
                            fullWidth
                            variant="secondary"
                            isLoading={isUpdating}
                            disabled={!note || (status === 'Resolved' && !capturedImage)}
                            icon={<Send className="h-4 w-4" />}
                        >
                            Complete Update
                        </Button>
                    </div>
                </Card>
            </div>
        </div>
    );
};

export default ManageComplaint;
