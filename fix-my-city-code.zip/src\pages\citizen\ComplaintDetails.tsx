import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, MapPin, Calendar, CheckCircle } from 'lucide-react';
import Card from '../../components/ui/Card';

const ComplaintDetails: React.FC = () => {
    const { id } = useParams<{ id: string }>();

    // Mock Data
    const complaint = {
        id: id || 'CMP-2023-001',
        type: 'Pothole Repair',
        description: 'Large pothole in the middle of the road causing traffic slowdowns. It is approximately 2 feet wide and 6 inches deep.',
        location: 'Main Street, Ward 4',
        coordinates: { lat: 12.9716, lng: 77.5946 },
        status: 'In Progress',
        date: '2023-05-15',
        department: 'Roads & Transport',
        assignedTo: 'Officer Sharma',
        timeline: [
            { status: 'Complaint Registered', date: '2023-05-15 10:30 AM', completed: true },
            { status: 'Assigned to Dept', date: '2023-05-15 02:00 PM', completed: true },
            { status: 'Work In Progress', date: '2023-05-16 09:00 AM', completed: true },
            { status: 'Resolution Verified', date: '-', completed: false }
        ],
        image: 'https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?auto=format&fit=crop&q=80&w=800'
    };

    return (
        <div className="min-h-screen bg-gray-50 pb-10">
            <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-10 border-b border-gray-100">
                <div className="px-4 h-16 flex items-center max-w-3xl mx-auto">
                    <Link to="/citizen/complaints" className="mr-4 p-2 -ml-2 rounded-full hover:bg-gray-100 transition-colors text-gray-600">
                        <ArrowLeft className="h-5 w-5" />
                    </Link>
                    <h1 className="text-lg font-bold text-gray-900">Complaint Details</h1>
                </div>
            </header>

            <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
                {/* Status Banner */}
                <div className={`p-4 rounded-xl border flex items-center justify-between ${complaint.status === 'Resolved' ? 'bg-green-50 border-green-200 text-green-800' :
                        complaint.status === 'In Progress' ? 'bg-yellow-50 border-yellow-200 text-yellow-800' :
                            'bg-blue-50 border-blue-200 text-blue-800'
                    }`}>
                    <div>
                        <span className="font-bold block text-lg">{complaint.status}</span>
                        <span className="text-sm opacity-80">Expected completion: 12 Days remaining</span>
                    </div>
                    <div className={`h-10 w-10 rounded-full flex items-center justify-center ${complaint.status === 'Resolved' ? 'bg-green-100' :
                            complaint.status === 'In Progress' ? 'bg-yellow-100' :
                                'bg-blue-100'
                        }`}>
                        <CheckCircle className="h-6 w-6" />
                    </div>
                </div>

                {/* Content */}
                <div className="space-y-6">
                    <div className="rounded-2xl overflow-hidden shadow-md h-64 relative group">
                        <img src={complaint.image} alt="Issue" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                        <div className="absolute bottom-4 left-4 text-white">
                            <h2 className="text-2xl font-bold">{complaint.type}</h2>
                            <p className="flex items-center text-sm opacity-90 mt-1">
                                <Calendar className="h-4 w-4 mr-1" /> {complaint.date}
                            </p>
                        </div>
                    </div>

                    <Card>
                        <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-3">Description</h3>
                        <p className="text-gray-700 leading-relaxed mb-6">{complaint.description}</p>

                        <div className="flex items-start text-sm text-gray-600 bg-gray-50 p-4 rounded-xl border border-gray-100">
                            <MapPin className="h-5 w-5 mr-3 text-red-500 mt-0.5 flex-shrink-0" />
                            <div>
                                <span className="block font-medium text-gray-900">Location</span>
                                <span>{complaint.location}</span>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4 mt-6 pt-6 border-t border-gray-100">
                            <div>
                                <span className="block text-gray-500 text-xs uppercase font-bold">Department</span>
                                <span className="font-medium text-gray-900 mt-1 block">{complaint.department}</span>
                            </div>
                            <div>
                                <span className="block text-gray-500 text-xs uppercase font-bold">Assigned To</span>
                                <span className="font-medium text-gray-900 mt-1 block">{complaint.assignedTo}</span>
                            </div>
                        </div>
                    </Card>

                    {/* Timeline */}
                    <Card>
                        <h3 className="font-bold text-gray-900 mb-6">Resolution Timeline</h3>
                        <div className="space-y-8 relative pl-2">
                            <div className="absolute top-2 bottom-2 left-[15px] w-0.5 bg-gray-100"></div>
                            {complaint.timeline.map((item, index) => (
                                <div key={index} className="relative flex items-start pl-10 group">
                                    <div className={`absolute left-0 h-8 w-8 rounded-full border-4 z-10 flex items-center justify-center transition-colors ${item.completed ? 'bg-green-500 border-green-100' : 'bg-white border-gray-200'
                                        }`}>
                                        {item.completed && <CheckCircle className="h-4 w-4 text-white" />}
                                        {!item.completed && <div className="h-2 w-2 rounded-full bg-gray-300"></div>}
                                    </div>
                                    <div className="flex-1">
                                        <p className={`text-sm font-bold ${item.completed ? 'text-gray-900' : 'text-gray-400'}`}>
                                            {item.status}
                                        </p>
                                        <p className="text-xs text-gray-400 mt-0.5 font-mono">{item.date}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </Card>
                </div>
            </div>
        </div>
    );
};

export default ComplaintDetails;
