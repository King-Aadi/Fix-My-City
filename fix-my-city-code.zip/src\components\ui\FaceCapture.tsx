import React, { useRef, useState, useEffect } from 'react';
import { Camera, RefreshCw, XCircle, SwitchCamera, Loader2 } from 'lucide-react';
import Button from './Button';
import * as faceapi from 'face-api.js';

interface FaceCaptureProps {
    onCapture: (imageFile: File, imageDataUrl: string) => void;
    label?: string;
    showPreview?: boolean;
    className?: string;
    enableFaceDetection?: boolean;
}

const FaceCapture: React.FC<FaceCaptureProps> = ({
    onCapture,
    label = "Capture Photo",
    showPreview = true,
    className = "",
    enableFaceDetection = true
}) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const overlayRef = useRef<HTMLCanvasElement>(null);
    const streamRef = useRef<MediaStream | null>(null);

    const [isCameraOpen, setIsCameraOpen] = useState(false);
    const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
    const [isInitializingCamera, setIsInitializingCamera] = useState(false);
    const [capturedImage, setCapturedImage] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [isModelLoading, setIsModelLoading] = useState(enableFaceDetection);
    const [isFaceDetected, setIsFaceDetected] = useState(!enableFaceDetection); // Default true if detection disabled

    const [modelLoadFailed, setModelLoadFailed] = useState(false);

    const isMounted = useRef(true);

    useEffect(() => {
        isMounted.current = true;
        return () => {
            isMounted.current = false;
            // Immediate cleanup of stream to prevent "Camera reserved" issues
            if (streamRef.current) {
                streamRef.current.getTracks().forEach(track => track.stop());
            }
        };
    }, []);

    // Load ML Models
    useEffect(() => {
        if (!enableFaceDetection) {
            setTimeout(() => setIsModelLoading(false), 0);
            return;
        }

        const loadModels = async () => {
            try {
                // Using a more reliable CDN or local assets if possible would be better
                // For now, we keep the original but handle errors better
                const MODEL_URL = 'https://justadudewhohacks.github.io/face-api.js/models';
                await faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL);
                if (isMounted.current) {
                    setIsModelLoading(false);
                }
            } catch (err) {
                console.error("Failed to load face models", err);
                if (isMounted.current) {
                    setIsModelLoading(false);
                    setModelLoadFailed(true);
                }
            }
        };
        loadModels();
    }, [enableFaceDetection]);

    const stopCamera = React.useCallback(() => {
        if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop());
            streamRef.current = null;
        }
        setIsCameraOpen(false);
        if (enableFaceDetection) setIsFaceDetected(false);
        setIsInitializingCamera(false);
    }, [enableFaceDetection]);

    const startFaceDetection = React.useCallback(() => {
        if (!enableFaceDetection) return () => { };

        const intervalId = setInterval(async () => {
            if (videoRef.current && overlayRef.current && isCameraOpen && !modelLoadFailed) {
                const video = videoRef.current;
                const canvas = overlayRef.current;

                if (video.paused || video.ended) return;

                // Simple check to ensure we have valid dimensions
                if (video.videoWidth === 0 || video.videoHeight === 0) return;

                const displaySize = { width: video.videoWidth, height: video.videoHeight };

                try {
                    faceapi.matchDimensions(canvas, displaySize);

                    const detections = await faceapi.detectAllFaces(video, new faceapi.TinyFaceDetectorOptions());
                    const resizedDetections = faceapi.resizeResults(detections, displaySize);

                    const ctx = canvas.getContext('2d');
                    if (ctx) {
                        ctx.clearRect(0, 0, canvas.width, canvas.height);
                        // Mirroring logic for drawing
                        if (facingMode === 'user') {
                            ctx.save();
                            ctx.scale(-1, 1);
                            ctx.translate(-canvas.width, 0);
                        }
                        faceapi.draw.drawDetections(canvas, resizedDetections);
                        if (facingMode === 'user') {
                            ctx.restore();
                        }
                    }

                    if (isMounted.current) setIsFaceDetected(detections.length > 0);
                } catch (e) {
                    console.error("Detection error:", e);
                    // If detection crashes repeatedly, disable it
                    clearInterval(intervalId);
                    if (isMounted.current) setModelLoadFailed(true);
                }
            }
        }, 200); // Increased interval to 200ms to reduce CPU load

        // Store interval to clear on stop (using streamRef closure trick or check isCameraOpen)
        return () => clearInterval(intervalId);
    }, [isCameraOpen, modelLoadFailed, facingMode, enableFaceDetection]);

    // Start detection once models are loaded if camera is open
    useEffect(() => {
        let cleanup: (() => void) | undefined;
        if (!isModelLoading && isCameraOpen && !modelLoadFailed) {
            try {
                cleanup = startFaceDetection();
            } catch (e) {
                console.error("Error starting detection loop", e);
                // In case of crash, enable capture
                setTimeout(() => {
                    if (isMounted.current) setIsFaceDetected(true);
                }, 0);
            }
        } else if (modelLoadFailed && isCameraOpen && !isFaceDetected) {
            // If ML failed, just auto-approve "face detected" so button enables
            // Use setTimeout to avoid synchronous state update in effect warning
            setTimeout(() => {
                if (isMounted.current) setIsFaceDetected(true);
            }, 0);
        }

        return () => {
            if (cleanup) cleanup();
        };
    }, [isModelLoading, isCameraOpen, modelLoadFailed, startFaceDetection, isFaceDetected]);
    const startCamera = React.useCallback(async (modeOverride?: 'user' | 'environment') => {
        if (!isMounted.current) return;

        const mode = modeOverride || facingMode;

        setError(null);
        setIsInitializingCamera(true);

        // Ensure any previous stream is fully stopped before starting a new one
        stopCamera();

        try {
            const stream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: mode }
            });

            // If component unmounted while waiting for permission, stop immediately
            if (!isMounted.current) {
                stream.getTracks().forEach(track => track.stop());
                return;
            }

            streamRef.current = stream;

            if (videoRef.current) {
                videoRef.current.srcObject = stream;
                // Important: playing must happen after metadata loaded
                videoRef.current.onloadedmetadata = () => {
                    if (!isMounted.current) return;
                    videoRef.current?.play()
                        .then(() => {
                            if (isMounted.current) {
                                setIsCameraOpen(true);
                                setIsInitializingCamera(false);
                            }
                        })
                        .catch(e => {
                            console.error("Play error:", e);
                            if (isMounted.current) {
                                setError("Could not start video stream.");
                                setIsInitializingCamera(false);
                            }
                        });
                };
            }
        } catch (err) {
            if (!isMounted.current) return;
            console.error("Camera Error:", err);

            // Fallback: If initial mode fails, try ANY camera
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ video: true });

                if (!isMounted.current) {
                    stream.getTracks().forEach(track => track.stop());
                    return;
                }

                streamRef.current = stream;
                if (videoRef.current) {
                    videoRef.current.srcObject = stream;
                    videoRef.current.onloadedmetadata = () => {
                        if (!isMounted.current) return;
                        videoRef.current?.play()
                            .then(() => {
                                if (isMounted.current) {
                                    setIsCameraOpen(true);
                                    setIsInitializingCamera(false);
                                }
                            })
                            .catch(e => {
                                console.error("Fallback Play error:", e);
                                if (isMounted.current) setIsInitializingCamera(false);
                            });
                    };
                }
            } catch {
                if (isMounted.current) {
                    setError("Could not access camera. Please allow permissions.");
                    setIsCameraOpen(false);
                    setIsInitializingCamera(false);
                }
            }
        }
    }, [facingMode, stopCamera]);

    // Restart camera when facingMode changes - REMOVED EFFECT LOOP
    // Triggered manually via toggleCamera now

    // Fallback: If no face detected after 3 seconds of camera being open, enable button manually
    useEffect(() => {
        let timeout: NodeJS.Timeout;
        if (isCameraOpen && !isFaceDetected) {
            timeout = setTimeout(() => {
                console.log("Fallback: Enabling capture button due to timeout");
                if (isMounted.current) setIsFaceDetected(true);
            }, 3000); // Reduced to 3 seconds for better UX
        }
        return () => clearTimeout(timeout);
    }, [isCameraOpen, isFaceDetected]);

    const toggleCamera = () => {
        const newMode = facingMode === 'user' ? 'environment' : 'user';
        setFacingMode(newMode);
        if (isCameraOpen) {
            startCamera(newMode);
        }
    };



    const handleCapture = () => {
        if (videoRef.current && canvasRef.current) {
            const video = videoRef.current;
            const canvas = canvasRef.current;

            // Ensure video is ready (at least HAVE_CURRENT_DATA)
            if (video.readyState < 2) {
                console.warn("Camera not ready yet (State:", video.readyState, ")");
                return;
            }

            // Set canvas dimensions to match video
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;

            const context = canvas.getContext('2d');
            if (context) {
                try {
                    // Draw image
                    if (facingMode === 'user') {
                        context.save();
                        context.scale(-1, 1);
                        context.translate(-canvas.width, 0);
                        context.drawImage(video, 0, 0, canvas.width, canvas.height);
                        context.restore();
                    } else {
                        context.drawImage(video, 0, 0, canvas.width, canvas.height);
                    }

                    const dataUrl = canvas.toDataURL('image/jpeg', 0.8);

                    canvas.toBlob((blob) => {
                        if (blob) {
                            const file = new File([blob], "face_capture.jpg", { type: "image/jpeg" });
                            setCapturedImage(dataUrl);
                            onCapture(file, dataUrl);
                            stopCamera();
                        } else {
                            console.error("Failed to create blob from canvas");
                            setError("Failed to process image. Please try again.");
                        }
                    }, 'image/jpeg', 0.8);
                } catch (err) {
                    console.error("Capture error:", err);
                    setError("Error capturing photo. Please try again.");
                }
            }
        }
    };

    const handleRetake = () => {
        setCapturedImage(null);
        startCamera();
    };



    return (
        <div className={`flex flex-col items-center justify-center space-y-4 ${className}`}>
            {/* Camera View / Preview Area */}
            <div className="relative w-full max-w-sm aspect-[4/3] bg-gray-100 rounded-xl overflow-hidden border-2 border-gray-200 shadow-inner flex items-center justify-center">

                {/* Initial State - Camera Off, No Image */}
                {!isCameraOpen && !capturedImage && !error && !isInitializingCamera && (
                    <button
                        type="button"
                        className="flex flex-col items-center justify-center w-full h-full cursor-pointer hover:bg-gray-200 transition-colors group border-none bg-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
                        onClick={() => startCamera()}
                    >
                        {isModelLoading ? (
                            <div className="absolute top-2 right-2 flex items-center gap-1 bg-white/80 px-2 py-1 rounded-full text-[10px] text-blue-600 shadow-sm">
                                <Loader2 className="h-3 w-3 animate-spin" />
                                <span>Initializing AI...</span>
                            </div>
                        ) : (
                            <div className="absolute top-2 right-2 flex items-center gap-1 bg-green-100 px-2 py-1 rounded-full text-[10px] text-green-700 shadow-sm">
                                <span>AI Ready</span>
                            </div>
                        )}

                        <div className="p-4 bg-white rounded-full shadow-sm mb-3 group-hover:scale-110 transition-transform">
                            <Camera className="h-8 w-8 text-blue-600" />
                        </div>
                        <p className="text-gray-500 font-medium">{label}</p>
                        <p className="text-xs text-gray-400 mt-1">Tap to start camera</p>
                    </button>
                )}

                {/* Camera Error / Fallback */}
                {error && (
                    <div className="flex flex-col items-center justify-center p-4 text-center">
                        <XCircle className="h-10 w-10 text-red-500 mb-2" />
                        <p className="text-red-600 font-medium text-sm mb-2">{error}</p>
                        <button
                            onClick={() => startCamera()}
                            className="text-blue-600 hover:underline text-sm"
                        >
                            Try Again
                        </button>
                    </div>
                )}

                {/* Live Video Feed - Always render video to ensure ref is available */}
                <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className={`absolute inset-0 w-full h-full object-cover ${facingMode === 'user' ? 'transform scale-x-[-1]' : ''} ${isCameraOpen ? '' : 'invisible'}`}
                />
                <canvas
                    ref={overlayRef}
                    className={`absolute inset-0 w-full h-full pointer-events-none ${isCameraOpen ? '' : 'invisible'}`}
                />

                {/* Spinner Overlay while initializing stream but before playing */}
                {isInitializingCamera && !error && (
                    <div className="absolute inset-0 flex items-center justify-center bg-white z-10">
                        <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
                    </div>
                )}

                {/* Captured Image Preview */}
                {capturedImage && showPreview && (
                    <img
                        src={capturedImage}
                        alt="Captured"
                        className="absolute inset-0 w-full h-full object-cover"
                    />
                )}
            </div>

            {/* Hidden Canvas for Processing */}
            <canvas ref={canvasRef} className="hidden" />

            {/* Controls */}
            <div className="flex justify-center w-full">
                {isCameraOpen && (
                    <>
                        <div className="relative">
                            <button
                                type="button"
                                onClick={handleCapture}
                                disabled={!isFaceDetected}
                                className={`h-14 w-14 rounded-full border-4 border-white shadow-lg transition-all focus:outline-none focus:ring-2 focus:ring-offset-2 ${isFaceDetected
                                    ? 'bg-red-500 hover:bg-red-600 hover:scale-105 focus:ring-red-500'
                                    : 'bg-gray-400 cursor-not-allowed opacity-50'
                                    }`}
                                aria-label="Capture photo"
                            />
                            {!isFaceDetected && (
                                <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap text-xs bg-black/70 text-white px-2 py-1 rounded">
                                    No Face Detected
                                </span>
                            )}
                        </div>

                        <div className="absolute right-4 bottom-4">
                            <Button
                                type="button"
                                variant="secondary"
                                onClick={toggleCamera}
                                className="rounded-full w-10 h-10 p-0 flex items-center justify-center shadow-md bg-white/80 backdrop-blur-sm"
                                title="Switch Camera"
                            >
                                <SwitchCamera className="h-5 w-5 text-gray-700" />
                            </Button>
                        </div>
                    </>
                )}

                {capturedImage && (
                    <Button
                        type="button"
                        variant="outline"
                        onClick={handleRetake}
                        icon={<RefreshCw className="h-4 w-4" />}
                    >
                        Retake Photo
                    </Button>
                )}
            </div>
        </div>
    );
};

export default FaceCapture;


