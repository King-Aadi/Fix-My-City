import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, ChevronRight, Clock, MapPin } from 'lucide-react';
import Card from '../../components/ui/Card';
import Input from '../../components/ui/Input';


import { useComplaints } from '../../hooks/useComplaints';

const ComplaintsList: React.FC = () => {
    const [filter, setFilter] = useState('All');
    const [searchTerm, setSearchTerm] = useState('');


    const { complaints } = useComplaints();

    const filteredComplaints = complaints.filter(c => {
        const matchesFilter = filter === 'All' || c.status === filter;
        const matchesSearch = c.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
            c.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
            c.id.toLowerCase().includes(searchTerm.toLowerCase());
        return matchesFilter && matchesSearch;
    });

    return (
        <div className="p-4 max-w-7xl mx-auto space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <h1 className="text-2xl font-bold text-gray-900">My Complaints</h1>
                <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0">
                    {['All', 'Submitted', 'In Progress', 'Resolved'].map((status) => (
                        <button
                            key={status}
                            onClick={() => setFilter(status)}
                            className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${filter === status
                                ? 'bg-blue-600 text-white shadow-md'
                                : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
                                }`}
                        >
                            {status}
                        </button>
                    ))}
                </div>
            </div>

            <Input
                placeholder="Search complaints..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                icon={<Search className="h-5 w-5" />}
                fullWidth
            />

            <div className="space-y-4">
                {filteredComplaints.length > 0 ? (
                    filteredComplaints.map((complaint) => (
                        <Link
                            key={complaint.id}
                            to={`/citizen/complaint/${complaint.id}`}
                            className="block group"
                        >
                            <Card className="hover:border-blue-300 transition-colors" padding="md">
                                <div className="flex justify-between items-start">
                                    <div className="flex-grow">
                                        <div className="flex justify-between items-center mb-2">
                                            <span className="font-bold text-gray-900 text-lg group-hover:text-blue-600 transition-colors">{complaint.type}</span>
                                            <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wide ${complaint.status === 'Resolved' ? 'bg-green-100 text-green-700' :
                                                complaint.status === 'In Progress' ? 'bg-yellow-100 text-yellow-700' :
                                                    'bg-blue-100 text-blue-700'
                                                }`}>
                                                {complaint.status}
                                            </span>
                                        </div>

                                        <div className="flex items-center text-sm text-gray-500 mb-3">
                                            <MapPin className="h-4 w-4 mr-1 text-gray-400" />
                                            {complaint.location}
                                        </div>

                                        <div className="flex items-center text-xs text-gray-400 border-t pt-3 border-gray-100">
                                            <Clock className="h-3 w-3 mr-1" />
                                            {complaint.date}
                                            <span className="mx-2">•</span>
                                            <span className="font-mono bg-gray-100 px-1.5 py-0.5 rounded text-gray-500">{complaint.id}</span>
                                        </div>
                                    </div>
                                    <ChevronRight className="h-5 w-5 text-gray-300 group-hover:text-blue-500 group-hover:translate-x-1 transition-all ml-4 self-center" />
                                </div>
                            </Card>
                        </Link>
                    ))
                ) : (
                    <div className="text-center py-16 bg-white rounded-2xl border border-dashed border-gray-300">
                        <div className="bg-gray-50 h-16 w-16 rounded-full flex items-center justify-center mx-auto mb-4">
                            <Search className="h-8 w-8 text-gray-400" />
                        </div>
                        <p className="text-gray-500 font-medium">No complaints found matching your search.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default ComplaintsList;
