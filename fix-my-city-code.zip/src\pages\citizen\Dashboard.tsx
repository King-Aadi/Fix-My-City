import React from 'react';
import { Link } from 'react-router-dom';
import { Plus, Clock, Award } from 'lucide-react';
import Card from '../../components/ui/Card';
import { db } from '../../services/storage';
import { useAuth } from '../../context/AuthContext';

const CitizenDashboard: React.FC = () => {
    const { user } = useAuth();

    // Get real data from DB
    const allComplaints = db.getComplaints();
    const myComplaints = user ? allComplaints.filter(c => c.userId === user.id) : [];

    // Calculate Stats
    const stats = {
        submitted: myComplaints.length,
        inProgress: myComplaints.filter(c => c.status === 'In Progress' || c.status === 'Assigned').length,
        resolved: myComplaints.filter(c => c.status === 'Resolved').length
    };

    // Calculate Citizen Score (Gamification)
    // +10 points for reporting (submitted), +50 points for resolution verification (resolved)
    // Simple logic: 10 * total + 40 * resolved (since total includes resolved)
    const citizenScore = (stats.submitted * 10) + (stats.resolved * 40);

    const recentComplaints = myComplaints.slice(0, 5);

    return (
        <div className="px-4 py-8 max-w-7xl mx-auto space-y-8 bg-grid-pattern min-h-screen">
            {/* Header */}
            <div className="flex justify-between items-end">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">Welcome, {user?.name || 'Resident'}!</h1>
                    <p className="text-gray-600 mt-1">Here's what's happening in your city today.</p>
                </div>
                <div className="hidden md:flex items-center space-x-2 bg-gradient-to-r from-amber-100 to-orange-100 px-4 py-2 rounded-full border border-orange-200">
                    <Award className="h-5 w-5 text-orange-600" />
                    <div>
                        <span className="text-xs font-bold text-orange-800 uppercase tracking-wider block">Citizen Score</span>
                        <span className="text-lg font-extrabold text-orange-900 leading-none">{citizenScore} pts</span>
                    </div>
                </div>
            </div>

            {/* Stats Cards - Glass Effect */}
            <div className="grid grid-cols-3 gap-6">
                <div className="glass rounded-2xl p-6 flex flex-col items-center justify-center text-center hover:scale-105 transition-transform duration-300 cursor-default group">
                    <div className="text-4xl font-bold text-blue-600 mb-2 group-hover:text-blue-700 transition-colors drop-shadow-sm">{stats.submitted}</div>
                    <div className="text-sm font-bold text-gray-500 uppercase tracking-wide">Total</div>
                </div>
                <div className="glass rounded-2xl p-6 flex flex-col items-center justify-center text-center hover:scale-105 transition-transform duration-300 cursor-default group">
                    <div className="text-4xl font-bold text-yellow-500 mb-2 group-hover:text-yellow-600 transition-colors drop-shadow-sm">{stats.inProgress}</div>
                    <div className="text-sm font-bold text-gray-500 uppercase tracking-wide">Pending</div>
                </div>
                <div className="glass rounded-2xl p-6 flex flex-col items-center justify-center text-center hover:scale-105 transition-transform duration-300 cursor-default group">
                    <div className="text-4xl font-bold text-green-500 mb-2 group-hover:text-green-600 transition-colors drop-shadow-sm">{stats.resolved}</div>
                    <div className="text-sm font-bold text-gray-500 uppercase tracking-wide">Resolved</div>
                </div>
            </div>

            {/* Mobile Score Card (visible only on small screens) */}
            <div className="md:hidden">
                <Card className="bg-gradient-to-r from-amber-50 to-orange-50 border-orange-200">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                            <div className="bg-orange-100 p-2 rounded-full">
                                <Award className="h-6 w-6 text-orange-600" />
                            </div>
                            <div>
                                <p className="text-xs font-bold text-orange-800 uppercase">Impact Score</p>
                                <p className="text-2xl font-extrabold text-orange-900">{citizenScore}</p>
                            </div>
                        </div>
                        <div className="text-right">
                            <span className="text-xs text-orange-700 font-medium">Top 5% Citizen</span>
                        </div>
                    </div>
                </Card>
            </div>

            {/* Main Action */}
            <div className="relative group mt-6 md:mt-0">
                <div className="absolute -inset-1 bg-gradient-primary rounded-2xl blur opacity-25 group-hover:opacity-75 transition duration-1000 group-hover:duration-200"></div>
                <Link
                    to="/citizen/report-issue"
                    className="relative w-full bg-gradient-primary text-white p-6 rounded-xl shadow-lg flex items-center justify-center space-x-3 hover:scale-[1.02] transition-transform duration-300"
                >
                    <Plus className="h-8 w-8" />
                    <span className="text-xl font-bold tracking-wide">Report New Issue</span>
                </Link>
            </div>

            {/* Recent Activity */}
            <div>
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-xl font-bold text-gray-900">Recent Activity</h2>
                    <Link to="/citizen/complaints" className="text-primary hover:text-blue-800 text-sm font-medium transition-colors">
                        View All
                    </Link>
                </div>

                <div className="space-y-4">
                    {recentComplaints.length > 0 ? (
                        recentComplaints.map((complaint) => (
                            <Link key={complaint.id} to={`/citizen/complaints/${complaint.id}`}>
                                <Card className="flex flex-row justify-between items-center group cursor-pointer border-l-4 border-l-transparent hover:border-l-primary mb-3" padding="md">
                                    <div>
                                        <h3 className="text-lg font-semibold text-gray-900 group-hover:text-primary transition-colors">{complaint.type}</h3>
                                        <p className="text-sm text-gray-500 mt-1">{complaint.location}</p>
                                        <div className="flex items-center text-xs text-gray-400 mt-2">
                                            <Clock className="h-3 w-3 mr-1" />
                                            {new Date(complaint.date).toLocaleDateString()}
                                            <span className="mx-2">•</span>
                                            {complaint.id}
                                        </div>
                                    </div>
                                    <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide ${complaint.status === 'Resolved' ? 'bg-green-100 text-green-700' :
                                        complaint.status === 'Rejected' ? 'bg-red-100 text-red-700' :
                                            'bg-yellow-100 text-yellow-700'
                                        }`}>
                                        {complaint.status}
                                    </span>
                                </Card>
                            </Link>
                        ))
                    ) : (
                        <div className="text-center py-8 text-gray-500 bg-gray-50 rounded-xl border border-dashed border-gray-300">
                            <p>No complaints filed yet.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default CitizenDashboard;
