import React, { createContext, useContext, useState } from 'react';
import { db } from '../services/storage';
import type { User } from '../services/storage';

interface AuthContextType {
    user: User | null;
    login: (email: string, password: string) => Promise<void>;
    register: (user: User) => Promise<void>;
    logout: () => void;
    updateProfile: (data: Partial<User>) => void;
    isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [user, setUser] = useState<User | null>(() => {
        const stored = db.getCurrentUser();
        return stored;
    });
    const [isLoading] = useState(false);
    // useEffect removed as state is initialized lazily

    const login = async (email: string, password: string) => {
        // Artificial delay for UX
        await new Promise(resolve => setTimeout(resolve, 800));
        const loggedUser = db.login(email, password);
        setUser(loggedUser);
    };

    const register = async (newUser: User) => {
        await new Promise(resolve => setTimeout(resolve, 800));
        db.saveUser(newUser);
    };

    const updateProfile = (data: Partial<User>) => {
        if (user) {
            const updatedUser = { ...user, ...data };
            db.updateUser(updatedUser);
            setUser(updatedUser);
        }
    };

    const logout = () => {
        db.logout();
        setUser(null);
        window.location.href = '/'; // Hard redirect to clear any state
    };

    return (
        <AuthContext.Provider value={{ user, login, register, logout, updateProfile, isLoading }}>
            {children}
        </AuthContext.Provider>
    );
};

// eslint-disable-next-line react-refresh/only-export-components
export const useAuth = () => {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};

// Moved useAuth hook export to be compatible with fast refresh or just ensure it is exported properly.
// The warning 'Fast refresh only works when a file only exports components' is usually because we export 'useAuth' hook alongside component.
// We can ignore it or move it. For now, we will leave it as it often works fine, but if strict, we should separate.
// Actually, to fix strict lint: "Fast refresh only works when a file only exports components".
// Use 'eslint-disable-next-line' or split file. I will split if necessary but usually disable is fine for hooks.
// Let's try to keep it simple, I will wrap the hook to make it happy or just leave it if it's a warning.
// Wait, the lint error was error level.
// I will move `useAuth` to a separate file `src/hooks/useAuth.ts`? No, simpler to just add `// eslint-disable-next-line react-refresh/only-export-components`

