import React, { useState, useCallback } from 'react';
import { GoogleMap, useJsApiLoader, Marker } from '@react-google-maps/api';

interface MapPickerProps {
    initialLat?: number;
    initialLng?: number;
    onLocationSelect: (lat: number, lng: number) => void;
}

const containerStyle = {
    width: '100%',
    height: '100%',
    borderRadius: '1rem'
};

const defaultCenter = {
    lat: 12.9716,
    lng: 77.5946
};

// **IMPORTANT**: Replace with your valid Google Maps API Key
// You can also set this in a .env file as VITE_GOOGLE_MAPS_API_KEY
const GOOGLE_MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';

const GoogleMapPicker: React.FC<MapPickerProps> = ({ initialLat, initialLng, onLocationSelect }) => {
    const { isLoaded, loadError } = useJsApiLoader({
        id: 'google-map-script',
        googleMapsApiKey: GOOGLE_MAPS_API_KEY
    });

    // Initialize state from props. 
    // If props change, we want to update the map, but we should do it cautiously or rely on `key` prop for full resets.
    // For this component, simpler is to just sync when props change if they are different from current.
    const [markerPos, setMarkerPos] = useState({ lat: initialLat || defaultCenter.lat, lng: initialLng || defaultCenter.lng });

    // State is initialized once. Parent handles resets via `key` prop.
    // Update internal state if props change (optional, but good for "controlled" feel if needed) - REMOVED to rely on key


    const onLoad = useCallback(function callback(map: google.maps.Map) {
        // map usage if needed, or leave empty but keep signature
        // rendering marker dynamically does not strictly require map ref here if using Marker component
        // To silence unused variable warning:
        console.log("Map Loaded", map.getZoom());
    }, []);

    const onUnmount = useCallback(function callback(map: google.maps.Map) {
        // Cleanup
        console.log("Map Unmounted", map.getZoom());
    }, []);

    const handleMapClick = (e: google.maps.MapMouseEvent) => {
        if (e.latLng) {
            const lat = e.latLng.lat();
            const lng = e.latLng.lng();
            setMarkerPos({ lat, lng });
            onLocationSelect(lat, lng);
        }
    };

    if (loadError) {
        return (
            <div className="h-full w-full flex items-center justify-center bg-gray-100 text-red-500 p-4 text-center">
                Error loading Google Maps. Please check your API Key.
            </div>
        );
    }

    if (!isLoaded) {
        return <div className="h-full w-full flex items-center justify-center bg-gray-100">Loading Map...</div>;
    }

    return (
        <GoogleMap
            mapContainerStyle={containerStyle}
            center={markerPos}
            zoom={15}
            onLoad={onLoad}
            onUnmount={onUnmount}
            onClick={handleMapClick}
            options={{
                streetViewControl: false,
                mapTypeControl: false,
                fullscreenControl: false,
            }}
        >
            <Marker position={markerPos} />
        </GoogleMap>
    );
};

export default GoogleMapPicker;
