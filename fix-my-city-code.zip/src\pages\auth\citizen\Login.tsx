import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, Lock, ArrowLeft, LogIn } from 'lucide-react';
import Card from '../../../components/ui/Card';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { useAuth } from '../../../context/AuthContext';

const CitizenLogin: React.FC = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    // Captcha State
    const [captcha, setCaptcha] = useState({ problem: '', answer: 0 });
    const [enteredCaptcha, setEnteredCaptcha] = useState('');

    const { login, isLoading } = useAuth();
    const navigate = useNavigate();

    const generateCaptcha = () => {
        const num1 = Math.floor(Math.random() * 10); // 0-9
        const num2 = Math.floor(Math.random() * 10); // 0-9
        setCaptcha({
            problem: `${num1} + ${num2}`,
            answer: num1 + num2
        });
        setEnteredCaptcha('');
    };

    // Generate Captcha on Mount
    React.useEffect(() => {
        generateCaptcha();
    }, []);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        if (parseInt(enteredCaptcha) !== captcha.answer) {
            setError('Incorrect Captcha answer. Please try again.');
            generateCaptcha();
            return;
        }

        try {
            await login(email, password);
            navigate('/citizen/dashboard');
        } catch (err) {
            setError((err as Error).message);
            generateCaptcha(); // Refresh on error too for security
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden">
            {/* Decorative Elements */}
            <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-blue-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
            <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] bg-purple-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>

            <div className="absolute top-6 left-6 z-10">
                <Link to="/auth/user-type" className="flex items-center text-gray-500 hover:text-gray-900 transition-colors bg-white/50 backdrop-blur-sm px-4 py-2 rounded-full shadow-sm hover:shadow">
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    Back
                </Link>
            </div>

            <div className="sm:mx-auto sm:w-full sm:max-w-md z-10">
                <div className="text-center mb-8">
                    <h2 className="text-3xl font-bold tracking-tight text-gray-900">
                        Welcome Back
                    </h2>
                    <p className="mt-2 text-sm text-gray-600">
                        Login to report issues and track status
                    </p>
                </div>

                <Card className="backdrop-blur-xl bg-white/90 shadow-xl border-white/50">
                    <form className="space-y-2" onSubmit={handleSubmit}>
                        {error && (
                            <div className="bg-red-50 text-red-600 p-3 rounded-md text-sm mb-4 border border-red-200">
                                {error}
                            </div>
                        )}
                        <Input
                            label="Email Address"
                            id="email"
                            type="email"
                            placeholder="you@example.com"
                            required
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            icon={<Mail className="h-5 w-5" />}
                        />

                        <Input
                            label="Password"
                            id="password"
                            type="password"
                            placeholder="••••••••"
                            required
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            icon={<Lock className="h-5 w-5" />}
                        />

                        {/* Captcha Section */}
                        <div className="bg-gray-50 p-3 rounded-xl border border-gray-200">
                            <div className="flex justify-between items-center mb-2">
                                <label className="block text-sm font-medium text-gray-700">Security Check</label>
                                <span className="text-xs text-gray-400">Solve to login</span>
                            </div>
                            <div className="flex gap-2 items-center">
                                <div className="bg-white px-4 py-2 rounded-lg border border-gray-300 font-mono text-lg font-bold tracking-widest select-none text-gray-600 w-1/3 text-center">
                                    {captcha.problem} = ?
                                </div>
                                <input
                                    type="number"
                                    className="block w-2/3 rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                                    placeholder="Answer"
                                    required
                                    value={enteredCaptcha}
                                    onChange={(e) => setEnteredCaptcha(e.target.value)}
                                />
                                <button
                                    type="button"
                                    onClick={generateCaptcha}
                                    className="p-2 text-gray-500 hover:text-blue-600 transition-colors"
                                    title="Refresh Captcha"
                                >
                                    <ArrowLeft className="h-4 w-4 rotate-180" /> {/* Refresh icon hack */}
                                </button>
                            </div>
                        </div>

                        <div className="flex items-center justify-between py-2">
                            {/* ... (Previous code) ... */}
                            <div className="flex items-center">
                                <input
                                    id="remember-me"
                                    name="remember-me"
                                    type="checkbox"
                                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                                />
                                <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-700">
                                    Remember me
                                </label>
                            </div>
                        </div>

                        <div className="pt-2">
                            <Button
                                type="submit"
                                fullWidth
                                isLoading={isLoading}
                                icon={<LogIn className="h-5 w-5" />}
                            >
                                Sign In
                            </Button>
                        </div>
                    </form>
                    <div className="mt-6 text-center">
                        <p className="text-sm text-gray-600">
                            New to FixMyCity?{' '}
                            <Link to="/auth/citizen/register" className="font-semibold text-blue-600 hover:text-blue-500 hover:underline">
                                Create an account
                            </Link>
                        </p>
                    </div>
                </Card>
            </div>
        </div>
    );
};

export default CitizenLogin;
