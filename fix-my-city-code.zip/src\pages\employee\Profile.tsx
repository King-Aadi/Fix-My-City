import React, { useState } from 'react';
import { Briefcase, LogOut, TrendingUp, CheckCircle, Mail, Edit2, Phone, MapPin } from 'lucide-react';
import Card from '../../components/ui/Card';
import { db } from '../../services/storage';
import Input from '../../components/ui/Input';
import Button from '../../components/ui/Button';
import { useAuth } from '../../context/AuthContext';

const EmployeeProfile: React.FC = () => {
    const { user, logout, updateProfile } = useAuth();
    const [isEditing, setIsEditing] = useState(false);
    const [formData, setFormData] = useState(() => {
        if (!user) return { name: '', department: 'Sanitation' };
        return {
            name: user.name,
            department: user.department || 'Sanitation'
        };
    });

    // useEffect removed


    const handleSave = () => {
        if (!user) return;
        updateProfile({
            name: formData.name,
            department: formData.department
        });
        setIsEditing(false);
    };

    if (!user) return <div className="p-8 text-center">Please login.</div>;

    // Calc Stats Dynamically
    const allComplaints = db.getComplaints();

    // Filter complaints relevant to this employee (by Zone essentially)
    const myZoneComplaints = (user.zone)
        ? allComplaints.filter(c => c.zone === user.zone)
        : []; // If no zone, maybe show global or nothing. Assuming Zone based.

    const resolvedCount = myZoneComplaints.filter(c => c.status === 'Resolved').length;
    const assignedCount = myZoneComplaints.filter(c => c.status === 'Assigned' || c.status === 'In Progress' || c.status === 'Resolved').length;

    // Performance Score Calculation
    // Base 50 + (Resolved / Total Assigned * 50)
    // If no tasks, default to 100 (new employee) or 0? Let's say 85 base.
    let performanceScore = 0;
    if (assignedCount === 0) {
        performanceScore = 85; // Default start score
    } else {
        const completionRate = resolvedCount / assignedCount;
        performanceScore = Math.min(100, Math.round(50 + (completionRate * 50)));
    }

    return (
        <div className="min-h-screen bg-gray-50 pb-24">
            {/* Header Banner */}
            {/* Header Banner - Premium Glassmorphism & Animations */}
            <div className="relative h-64 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-800 animate-gradient-x"></div>

                {/* Animated Background Shapes */}
                <div className="absolute top-[-50%] left-[-20%] w-[80%] h-[200%] bg-emerald-400/20 rounded-full blur-3xl animate-blob"></div>
                <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[150%] bg-cyan-400/20 rounded-full blur-3xl animate-blob animation-delay-2000"></div>

                {/* Texture Overlay */}
                <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
            </div>

            <div className="max-w-3xl mx-auto px-4 -mt-24 relative z-10">
                {/* Profile Card - Glass Effect */}
                <div className="glass rounded-3xl p-6 flex flex-col items-center text-center relative overflow-visible pt-16 animate-fade-in-up ring-1 ring-white/50">
                    <div className="absolute -top-16 left-1/2 transform -translate-x-1/2">
                        <div className="h-32 w-32 bg-white/30 backdrop-blur-md rounded-full p-2 shadow-2xl ring-4 ring-white/60 animate-float">
                            <div className="h-full w-full bg-gradient-to-br from-emerald-100 to-teal-100 rounded-full flex items-center justify-center text-emerald-600 shadow-inner">
                                <span className="text-5xl font-extrabold drop-shadow-sm">{user.name.charAt(0).toUpperCase()}</span>
                            </div>
                        </div>
                    </div>

                    {!isEditing ? (
                        <>
                            <h1 className="text-2xl font-bold text-gray-900">{user.name}</h1>
                            <p className="text-emerald-600 font-medium bg-emerald-50 px-3 py-1 rounded-full text-xs mt-2 uppercase tracking-wide">
                                {user.department || 'General Staff'}
                            </p>
                            <button
                                onClick={() => setIsEditing(true)}
                                className="absolute top-4 right-4 text-gray-400 hover:text-emerald-600 p-2"
                            >
                                <Edit2 className="h-4 w-4" />
                            </button>
                        </>
                    ) : (
                        <div className="w-full max-w-sm space-y-3 mt-2">
                            <Input
                                label="Name"
                                value={formData.name}
                                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                            />
                            <Input
                                label="Department"
                                value={formData.department}
                                onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                            />
                            <div className="flex gap-2 justify-center mt-2">
                                <Button variant="outline" onClick={() => setIsEditing(false)} className="py-2 px-4 text-xs">Cancel</Button>
                                <Button onClick={handleSave} className="py-2 px-4 text-xs">Save</Button>
                            </div>
                        </div>
                    )}


                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                    <Card className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white border-none shadow-xl hover:shadow-2xl transition-shadow duration-300 overflow-hidden relative">
                        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl -mr-16 -mt-16"></div>
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-emerald-100 text-xs font-bold uppercase tracking-wide">Performance Score</p>
                                <p className="text-3xl font-bold mt-1">{performanceScore}/100</p>
                                <p className="text-emerald-100 text-xs mt-1">+2.4% from last month</p>
                            </div>
                            <div className="bg-white/20 p-3 rounded-xl backdrop-blur-sm">
                                <TrendingUp className="h-8 w-8 text-white" />
                            </div>
                        </div>
                    </Card>

                    <Card className="bg-white border-none shadow-md">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-gray-500 text-xs font-bold uppercase tracking-wide text-left">Tasks Resolved</p>
                                <p className="text-3xl font-bold mt-1 text-gray-900 text-left">{resolvedCount}</p>
                                <p className="text-green-600 text-xs mt-1 text-left font-medium">This Month</p>
                            </div>
                            <div className="bg-green-50 p-3 rounded-xl">
                                <CheckCircle className="h-8 w-8 text-green-600" />
                            </div>
                        </div>
                    </Card>
                </div>

                <div className="mt-6 space-y-6">
                    <Card>
                        <h3 className="font-bold text-gray-900 mb-4 flex items-center">
                            <Briefcase className="h-4 w-4 mr-2 text-gray-400" />
                            Employment Details
                        </h3>
                        <div className="space-y-4">
                            <div className="flex items-center justify-between p-4 bg-gray-50/50 rounded-xl hover:bg-gray-50 transition-colors border border-gray-100">
                                <span className="text-sm text-gray-500 flex items-center font-medium"><Briefcase className="h-4 w-4 mr-3 text-emerald-500" />Employee ID</span>
                                <span className="text-sm font-semibold text-gray-900 font-mono">EMP-{user.id.slice(0, 4).toUpperCase()}</span>
                            </div>
                            <div className="flex items-center justify-between p-4 bg-gray-50/50 rounded-xl hover:bg-gray-50 transition-colors border border-gray-100">
                                <span className="text-sm text-gray-500 flex items-center font-medium"><Mail className="h-4 w-4 mr-3 text-emerald-500" />Email</span>
                                <span className="text-sm font-semibold text-gray-900">{user.email}</span>
                            </div>
                            <div className="flex items-center justify-between p-4 bg-gray-50/50 rounded-xl hover:bg-gray-50 transition-colors border border-gray-100">
                                <span className="text-sm text-gray-500 flex items-center font-medium"><Phone className="h-4 w-4 mr-3 text-emerald-500" />Phone</span>
                                <span className="text-sm font-semibold text-gray-900">{user.phone || 'Not provided'}</span>
                            </div>
                            <div className="flex items-center justify-between p-4 bg-gray-50/50 rounded-xl hover:bg-gray-50 transition-colors border border-gray-100">
                                <span className="text-sm text-gray-500 flex items-center font-medium"><MapPin className="h-4 w-4 mr-3 text-emerald-500" />Zone Assignment</span>
                                <span className="text-sm font-semibold text-gray-900 text-right">
                                    {user.zone ? (
                                        <>
                                            <span className="block text-emerald-700">{user.zone} Zone</span>
                                            <span className="text-xs text-gray-400 font-normal">{user.district || ''}{user.state ? `, ${user.state}` : ''}</span>
                                        </>
                                    ) : (
                                        <span className="text-gray-400 italic">No Zone Assigned</span>
                                    )}
                                </span>
                            </div>
                        </div>
                    </Card>

                    <button
                        onClick={logout}
                        className="w-full flex items-center justify-center p-4 bg-white border-2 border-red-50 text-red-600 font-bold rounded-2xl hover:bg-red-50 hover:border-red-100 transition-all shadow-sm"
                    >
                        <LogOut className="h-5 w-5 mr-2" />
                        Log Out System
                    </button>

                    <div className="text-center text-xs text-gray-400 pb-8">
                        Municipal Employee Portal v2.1
                    </div>
                </div>
            </div>
        </div>
    );
};

export default EmployeeProfile;
