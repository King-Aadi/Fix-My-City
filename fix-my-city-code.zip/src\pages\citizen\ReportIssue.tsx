import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import LocationStep from '../../components/report/LocationStep';
import PhotoStep from '../../components/report/PhotoStep';
import FaceVerificationStep from '../../components/report/FaceVerificationStep';

import { db } from '../../services/storage';
import { emailService } from '../../services/email';
import { useAuth } from '../../context/AuthContext';

const ReportIssue: React.FC = () => {
    const navigate = useNavigate();
    const { user } = useAuth();
    const [step, setStep] = useState(1);
    const [formData, setFormData] = useState({
        location: '',
        coordinates: null as { lat: number, lng: number } | null,
        issueImage: null as File | null,
        description: '',
        faceImage: null as File | null
    });

    const handleLocationNext = (data: { location: string; coordinates: { lat: number; lng: number } }) => {
        setFormData(prev => ({ ...prev, ...data }));
        setStep(2);
    };

    const handlePhotoNext = (data: { image: File; description: string }) => {
        setFormData(prev => ({ ...prev, issueImage: data.image, description: data.description }));
        setStep(3);
    };

    const handleFaceNext = async (data: { faceImage: File }) => {
        // Prepare final data
        const finalData = {
            ...formData,
            faceImage: data.faceImage
        };

        // 1. Check for Duplicate Complaints
        const allComplaints = db.getComplaints();
        const duplicate = allComplaints.find(c =>
            c.status !== 'Resolved' &&
            c.status !== 'Rejected' &&
            c.location.toLowerCase().trim() === finalData.location.toLowerCase().trim()
        );

        if (duplicate) {
            const confirmRedirect = window.confirm(
                `A similar complaint (ID: ${duplicate.id}) already exists at this location.\n\n` +
                `Instead of creating a new one, would you like to view and track the existing report?`
            );

            if (confirmRedirect) {
                navigate(`/citizen/complaint/${duplicate.id}`);
            } else {
                navigate(`/citizen/complaint/${duplicate.id}`);
            }
            return;
        }

        // 2. Process Image
        let issueImageUrl = '';
        if (finalData.issueImage) {
            try {
                // In real app, upload to server. Here, local DB.
                issueImageUrl = await db.fileToBase64(finalData.issueImage);
            } catch (e) {
                console.error("Failed to process image", e);
            }
        }

        // 3. Save Complaint

        // Extract 'Identified: Type' from description if present
        const aiTypeMatch = finalData.description.match(/Identified: ([^.]+)/);
        const issueType = aiTypeMatch ? aiTypeMatch[1].trim() : 'General Issue';

        const complaintId = 'CMP-' + Date.now();
        db.addComplaint({
            id: complaintId,
            type: issueType,
            description: finalData.description,
            location: finalData.location,
            coordinates: finalData.coordinates || { lat: 0, lng: 0 },
            status: 'Submitted',
            date: new Date().toLocaleDateString(),
            image: issueImageUrl,
            userId: user?.id || 'guest',
            priority: 'Medium'
        });

        // Send Email Notification
        if (user?.email) {
            emailService.sendEmail({
                to_name: user.name,
                to_email: user.email,
                message: `Complaint Registered: ${complaintId}\n\nDear ${user.name},\n\nYour complaint regarding "${issueType}" at "${finalData.location}" has been successfully registered.\n\nComplaint ID: ${complaintId}\nStatus: Submitted\n\nWe will update you once an officer is assigned.\n\n- FixMyCity Team`
            });
        }

        console.log('Submitted Complaint to DB');
        navigate('/citizen/complaint-confirmation', { state: { complaintId } });
    };

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col">
            {/* Header */}
            <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-10 border-b border-gray-100">
                <div className="max-w-3xl mx-auto w-full px-4 h-16 flex items-center justify-between">
                    <button
                        onClick={() => navigate(-1)}
                        className="p-2 -ml-2 text-gray-500 hover:text-gray-900 hover:bg-gray-100 rounded-full transition-all"
                    >
                        <ArrowLeft className="h-5 w-5" />
                    </button>
                    <h1 className="text-lg font-bold text-gray-900">New Report</h1>
                    <div className="w-8"></div> {/* Spacer for center alignment */}
                </div>
                {/* Progress Bar */}
                <div className="h-1 w-full bg-gray-100">
                    <div
                        className="h-full bg-gradient-primary transition-all duration-500 ease-out shadow-[0_0_10px_rgba(59,130,246,0.5)]"
                        style={{ width: `${(step / 2) * 100}%` }}
                    />
                </div>
            </header>

            <main className="flex-grow p-4 md:p-8 max-w-xl mx-auto w-full">
                <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 md:p-8">
                    {step === 1 && <LocationStep onNext={handleLocationNext} />}
                    {step === 2 && <PhotoStep onNext={handlePhotoNext} onBack={() => setStep(1)} />}
                    {step === 3 && <FaceVerificationStep onNext={handleFaceNext} onBack={() => setStep(2)} />}
                </div>
            </main>
        </div>
    );
};

export default ReportIssue;
