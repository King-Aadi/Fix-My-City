import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { User, Mail, Lock, ArrowLeft, BadgeCheck, Phone, MapPin } from 'lucide-react';
import Card from '../../../components/ui/Card';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { useAuth } from '../../../context/AuthContext';
import { emailService } from '../../../services/email';

const EmployeeRegister: React.FC = () => {
    const [formData, setFormData] = useState({
        fullName: '',
        email: '',
        phone: '',
        department: '',
        state: '',
        district: '',
        zone: '',
        password: '',
        confirmPassword: ''
    });

    // OTP State
    const [otpSent, setOtpSent] = useState(false);
    const [generatedOtp, setGeneratedOtp] = useState('');
    const [enteredOtp, setEnteredOtp] = useState('');
    const [isPhoneVerified, setIsPhoneVerified] = useState(false);

    // ID Card State
    const [identityCardImage, setIdentityCardImage] = useState<string | null>(null);
    const [identityCardName, setIdentityCardName] = useState<string | null>(null);

    const { register, isLoading } = useAuth();
    const navigate = useNavigate();

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setIdentityCardName(file.name);
            const reader = new FileReader();
            reader.onloadend = () => {
                setIdentityCardImage(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    const sendOtp = () => {
        if (!formData.phone) return;
        const code = Math.floor(1000 + Math.random() * 9000).toString();
        setGeneratedOtp(code);
        setOtpSent(true);
        alert(`[MOCK SMS] Your Verification Code is: ${code}`);
    };

    const verifyOtp = () => {
        if (enteredOtp === generatedOtp) {
            setIsPhoneVerified(true);
            alert("Phone Verified Successfully!");
        } else {
            alert("Invalid OTP. Please try again.");
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!isPhoneVerified) {
            alert("Please verify your phone number first!");
            return;
        }

        if (formData.password !== formData.confirmPassword) {
            alert("Passwords don't match!");
            return;
        }

        if (!formData.state || !formData.district || !formData.zone) {
            alert("Please select your assigned location (State, District, Zone).");
            return;
        }

        if (!identityCardImage) {
            alert("Please upload your Official ID Card for verification.");
            return;
        }

        try {
            await register({
                id: 'EMP-' + Date.now(),
                name: formData.fullName,
                email: formData.email,
                phone: formData.phone,
                role: 'employee',
                department: formData.department,
                state: formData.state,
                district: formData.district,
                zone: formData.zone,
                password: formData.password,
                identityCardImage: identityCardImage
            });

            // Send Welcome Email
            emailService.sendEmail({
                to_name: formData.fullName,
                to_email: formData.email,
                message: `Official Account Created - FixMyCity\n\nOfficer ${formData.fullName},\n\nYour official account for the ${formData.department} department has been successfully created.\n\nAssigned Zone: ${formData.zone}, ${formData.district}\n\nPlease log in to view assigned tasks and manage complaints.\n\nBest Regards,\nFixMyCity Administration`
            });

            alert('Registration Successful! Please login.');
            navigate('/auth/employee/login');
        } catch (error) {
            const msg = (error as Error).message;
            if (msg.includes('already assigned')) {
                alert(`Registration Failed: ${msg}`);
            } else {
                alert('Registration Failed: ' + msg);
            }
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-green-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
            <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-teal-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>

            <div className="absolute top-6 left-6 z-10">
                <Link to="/auth/user-type" className="flex items-center text-gray-500 hover:text-gray-900 transition-colors bg-white/50 backdrop-blur-sm px-4 py-2 rounded-full shadow-sm hover:shadow">
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    Back
                </Link>
            </div>

            <div className="sm:mx-auto sm:w-full sm:max-w-md z-10">
                <div className="text-center mb-8">
                    <h2 className="text-3xl font-bold tracking-tight text-gray-900">
                        Employee Registration
                    </h2>
                    <p className="mt-2 text-sm text-gray-600">
                        Create an official municipality account
                    </p>
                </div>

                <Card className="backdrop-blur-xl bg-white/90 shadow-xl border-white/50 border-t-4 border-t-emerald-500">
                    <form className="space-y-3" onSubmit={handleSubmit}>
                        <Input
                            label="Full Name"
                            name="fullName"
                            type="text"
                            placeholder="Officer Name"
                            required
                            value={formData.fullName}
                            onChange={handleChange}
                            icon={<User className="h-5 w-5" />}
                        />
                        <Input
                            label="Official Email"
                            name="email"
                            type="email"
                            placeholder="officer@municipality.gov"
                            required
                            value={formData.email}
                            onChange={handleChange}
                            icon={<Mail className="h-5 w-5" />}
                        />
                        <Input
                            label="Department"
                            name="department"
                            type="text"
                            placeholder="Sanitation, Roads, etc."
                            required
                            value={formData.department}
                            onChange={handleChange}
                            icon={<BadgeCheck className="h-5 w-5" />}
                        />

                        {/* Location Selection */}
                        <div className="grid grid-cols-2 gap-2">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">State</label>
                                <div className="relative">
                                    <select
                                        name="state"
                                        required
                                        className="appearance-none block w-full pl-3 pr-10 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
                                        value={formData.state}
                                        onChange={handleChange}
                                    >
                                        <option value="">Select State</option>
                                        <option value="Karnataka">Karnataka</option>
                                        <option value="Tamil Nadu">Tamil Nadu</option>
                                    </select>
                                </div>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">District</label>
                                <div className="relative">
                                    <select
                                        name="district"
                                        required
                                        className="appearance-none block w-full pl-3 pr-10 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
                                        value={formData.district}
                                        onChange={handleChange}
                                    >
                                        <option value="">Select District</option>
                                        <option value="Bangalore">Bangalore</option>
                                        <option value="Chennai">Chennai</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Assigned Zone</label>
                            <div className="relative rounded-md shadow-sm">
                                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <MapPin className="h-5 w-5 text-gray-400" />
                                </div>
                                <select
                                    name="zone"
                                    required
                                    className="appearance-none block w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
                                    value={formData.zone}
                                    onChange={handleChange}
                                >
                                    <option value="">Select Zone</option>
                                    <option value="North">North Zone</option>
                                    <option value="South">South Zone</option>
                                    <option value="East">East Zone</option>
                                    <option value="West">West Zone</option>
                                </select>
                            </div>
                            <p className="mt-1 text-xs text-gray-500">Only one officer can be assigned per zone.</p>
                        </div>

                        <div className="space-y-2">
                            <div className="flex gap-2 items-end">
                                <div className="flex-1">
                                    <Input
                                        label="Phone Number"
                                        name="phone"
                                        type="tel"
                                        placeholder="+91 98765 43210"
                                        required
                                        value={formData.phone}
                                        onChange={handleChange}
                                        icon={<Phone className="h-5 w-5" />}
                                        disabled={isPhoneVerified}
                                    />
                                </div>
                                {!isPhoneVerified && (
                                    <Button
                                        type="button"
                                        variant="outline"
                                        className="mb-[2px]"
                                        onClick={sendOtp}
                                        disabled={!formData.phone || otpSent}
                                    >
                                        {otpSent ? 'Sent' : 'Verify'}
                                    </Button>
                                )}
                            </div>

                            {otpSent && !isPhoneVerified && (
                                <div className="flex gap-2 animate-fade-in bg-emerald-50 p-3 rounded-lg border border-emerald-100">
                                    <input
                                        type="text"
                                        placeholder="Enter OTP"
                                        className="flex-1 rounded-md border-gray-300 text-sm focus:ring-emerald-500 focus:border-emerald-500"
                                        value={enteredOtp}
                                        onChange={(e) => setEnteredOtp(e.target.value)}
                                    />
                                    <Button type="button" className="py-1 px-3 text-xs bg-emerald-600 hover:bg-emerald-700" onClick={verifyOtp}>Confirm</Button>
                                </div>
                            )}

                            {isPhoneVerified && (
                                <p className="text-xs text-emerald-600 font-bold flex items-center mt-1">
                                    ✓ Phone Verified
                                </p>
                            )}
                        </div>

                        <Input
                            label="Password"
                            name="password"
                            type="password"
                            placeholder="••••••••"
                            required
                            value={formData.password}
                            onChange={handleChange}
                            icon={<Lock className="h-5 w-5" />}
                        />
                        <Input
                            label="Confirm Password"
                            name="confirmPassword"
                            type="password"
                            placeholder="••••••••"
                            required
                            value={formData.confirmPassword}
                            onChange={handleChange}
                            icon={<Lock className="h-5 w-5" />}
                        />

                        {/* ID Card Upload */}
                        <div className="pt-2">
                            <label className="block text-sm font-medium text-gray-700 mb-1">Upload Official ID Card</label>
                            <div className="flex items-center gap-3">
                                <label className="flex-1 cursor-pointer bg-white border border-gray-300 rounded-md shadow-sm py-2 px-3 text-sm leading-4 font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 text-center">
                                    <span>{identityCardName || 'Choose File'}</span>
                                    <input
                                        type="file"
                                        className="hidden"
                                        accept="image/*"
                                        onChange={handleFileChange}
                                        required
                                    />
                                </label>
                                {identityCardImage && <span className="text-emerald-600 text-xs font-bold">✓ Uploaded</span>}
                            </div>
                            <p className="mt-1 text-xs text-gray-500">Required for verification.</p>
                        </div>

                        <div className="pt-4">
                            <Button
                                type="submit"
                                fullWidth
                                variant="secondary"
                                isLoading={isLoading}
                            >
                                Register Account
                            </Button>
                        </div>
                    </form>
                    <div className="mt-6 text-center">
                        <p className="text-sm text-gray-600">
                            Already registered?{' '}
                            <Link to="/auth/employee/login" className="font-semibold text-emerald-600 hover:text-emerald-500 hover:underline">
                                Login here
                            </Link>
                        </p>
                    </div>
                </Card>
            </div>
        </div>
    );
};

export default EmployeeRegister;
