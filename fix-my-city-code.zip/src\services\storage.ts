// Local Storage Service

const STORAGE_KEYS = {
    USERS: 'fmc_users',
    CURRENT_USER: 'fmc_current_user',
    COMPLAINTS: 'fmc_complaints'
};

// Types (You might want to move these to a separate types file later)
export interface User {
    id: string;
    name: string;
    email: string;
    phone?: string;
    role: 'citizen' | 'employee';
    department?: string; // For employees
    state?: string;
    district?: string;
    zone?: string;
    faceVerificationImage?: string; // Base64 image data for face matching
    password?: string; // In a real app, never store plain text!
    identityType?: 'Aadhar' | 'Driving License' | 'PAN Card' | 'Voter ID';
    identityNumber?: string;
    identityCardImage?: string; // For employees to upload ID card
}

export interface Complaint {
    id: string;
    type: string;
    description: string;
    location: string;
    zone?: string;
    coordinates: { lat: number; lng: number };
    status: 'Submitted' | 'Assigned' | 'In Progress' | 'Resolved' | 'Rejected';
    date: string;
    image?: string; // Base64 or URL
    priority?: 'High' | 'Medium' | 'Low';
    userId: string; // ID of the citizen who reported
    assignedTo?: string; // ID of the employee
    updates?: { date: string; status: string; note: string; proof?: string }[];
}

export const db = {
    // --- User Management ---
    getUsers: (): User[] => {
        const users = localStorage.getItem(STORAGE_KEYS.USERS);
        return users ? JSON.parse(users) : [];
    },

    // Helper to dispatch change events
    notifyListeners: () => {
        window.dispatchEvent(new Event('fmc-storage-update'));
    },

    saveUser: (user: User) => {
        const users = db.getUsers();
        // Check if email exists
        if (users.find(u => u.email === user.email)) {
            throw new Error('User already exists');
        }
        // Unique Employee Zone Constraint
        if (user.role === 'employee' && user.zone && user.district && user.state) {
            const assignmentExists = users.find(u =>
                u.role === 'employee' &&
                u.state === user.state &&
                u.district === user.district &&
                u.zone === user.zone
            );
            if (assignmentExists) {
                throw new Error(`The zone '${user.zone}' in ${user.district} is already assigned to ${assignmentExists.name}.`);
            }
        }
        users.push(user);
        localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
        db.notifyListeners();
    },

    updateUser: (updatedUser: User) => {
        const users = db.getUsers();
        const index = users.findIndex(u => u.id === updatedUser.id);
        if (index !== -1) {
            users[index] = updatedUser;
            localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
            // Update current user if it matches
            const currentUser = db.getCurrentUser();
            if (currentUser && currentUser.id === updatedUser.id) {
                localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(updatedUser));
            }
            db.notifyListeners();
        }
    },

    findUser: (email: string): User | undefined => {
        const users = db.getUsers();
        return users.find(u => u.email === email);
    },

    login: (email: string, password: string): User => {
        const user = db.findUser(email);
        if (!user) {
            throw new Error('User not found');
        }
        if (user.password !== password) {
            throw new Error('Invalid password');
        }
        // Set Session
        localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
        db.notifyListeners();
        return user;
    },

    logout: () => {
        localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
        db.notifyListeners();
    },

    getCurrentUser: (): User | null => {
        const user = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
        return user ? JSON.parse(user) : null;
    },

    // --- Complaint Management ---
    getComplaints: (): Complaint[] => {
        const complaints = localStorage.getItem(STORAGE_KEYS.COMPLAINTS);
        // Return stored complaints or seed with some mock data if empty for demo
        if (!complaints) {
            return [];
        }
        return JSON.parse(complaints);
    },

    addComplaint: (complaint: Complaint) => {
        const complaints = db.getComplaints();
        // Mock Auto-Assign Zone if missing (for demo purposes)
        if (!complaint.zone) {
            const zones = ['North', 'South', 'East', 'West'];
            complaint.zone = zones[Math.floor(Math.random() * zones.length)];
        }
        complaints.unshift(complaint); // Add to top
        localStorage.setItem(STORAGE_KEYS.COMPLAINTS, JSON.stringify(complaints));
        db.notifyListeners();
    },

    updateComplaint: (id: string, updates: Partial<Complaint>) => {
        const complaints = db.getComplaints();
        const index = complaints.findIndex(c => c.id === id);
        if (index !== -1) {
            complaints[index] = { ...complaints[index], ...updates };
            localStorage.setItem(STORAGE_KEYS.COMPLAINTS, JSON.stringify(complaints));
            db.notifyListeners();
        }
    },

    // Helper to convert File to Base64
    fileToBase64: (file: File): Promise<string> => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = error => reject(error);
        });
    }
};
